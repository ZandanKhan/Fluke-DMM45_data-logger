# Change Log

## R07, version 1.4.0

- Added continuous live primary and secondary display acquisition.
- Added START LIVE DISPLAY and STOP LIVE DISPLAY controls.
- Added an independent live display interval in seconds.
- Renamed the logging interval to CSV interval in seconds.
- Changed CSV duration input from seconds to minutes.
- Removed the UTC timestamp column from CSV output.
- Retained local PC timestamps with millisecond resolution.
- Added monitor lifecycle events and a dedicated worker acquisition mode.
- Added migration of prior R06 duration settings from seconds to minutes.
- Added live monitor, duration conversion, CSV schema, and GUI contract tests.
- Updated version to 1.4.0.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHONUTF8=1"
set "PYTHON_EXE=.venv\Scripts\python.exe"

if not exist "%PYTHON_EXE%" (
    echo The private Python environment is missing.
    echo Run install_fluke45.bat first.
    pause
    exit /b 1
)

echo ============================================================
echo Fluke 45 Logger R07 Diagnostics
echo ============================================================
"%PYTHON_EXE%" --version
"%PYTHON_EXE%" -c "from fluke45.tk_runtime import configure_tk_runtime; r=configure_tk_runtime(); print('Tcl:', r.tcl_library); print('Tk:', r.tk_library)"
"%PYTHON_EXE%" -c "from fluke45.tk_runtime import configure_tk_runtime; configure_tk_runtime(); import tkinter as tk; root=tk.Tk(); root.withdraw(); print('Tk runtime:', root.tk.call('info', 'patchlevel')); root.destroy()"
"%PYTHON_EXE%" -c "import serial; print('pyserial', serial.VERSION)"
"%PYTHON_EXE%" -m serial.tools.list_ports -v
"%PYTHON_EXE%" -m unittest discover -s tests -v

echo.
echo Diagnostics completed.
pause

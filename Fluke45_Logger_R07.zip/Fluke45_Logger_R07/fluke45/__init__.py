"""Fluke 45 serial data logger package."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "1.4.0"

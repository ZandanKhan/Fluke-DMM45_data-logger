"""Tkinter graphical interface for the Fluke 45 data logger."""

from __future__ import annotations

import logging
import os
import queue
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext, ttk

import serial
import serial.tools.list_ports

from fluke45 import __version__
from fluke45.config import AppConfig, load_config, save_config
from fluke45.models import (
    FLUKE45_BAUD_RATES,
    MAX_SAMPLE_INTERVAL_S,
    MAX_SESSION_DURATION_MINUTES,
    MIN_SAMPLE_INTERVAL_S,
    DeviceIdentity,
    EventKind,
    MeterRate,
    MeterReading,
    MonitorSettings,
    ParityMode,
    SerialSettings,
    SessionSettings,
    WorkerCommand,
    WorkerCommandKind,
    WorkerEvent,
)
from fluke45.tk_runtime import (
    TkRuntimeError,
    configure_tk_runtime,
)
from fluke45.worker import InstrumentWorker

LOGGER = logging.getLogger(__name__)
APP_TITLE = "Fluke 45 Dual Display Logger"
MAX_EVENT_LOG_LINES = 1_000
COMMON_BAUD_RATES = tuple(
    str(baud_rate) for baud_rate in FLUKE45_BAUD_RATES
)


class UiPalette:
    """Color palette used by the standard Tkinter interface.

    Args:
        appearance: Requested ``dark`` or ``light`` appearance.
    """

    def __init__(self, appearance: str) -> None:
        """Initialize a validated color palette.

        Args:
            appearance: Requested ``dark`` or ``light`` appearance.
        """
        normalized = appearance.lower().strip()
        self.appearance = normalized if normalized == "light" else "dark"
        if self.appearance == "light":
            self.window = "#F3F6F9"
            self.panel = "#FFFFFF"
            self.panel_alt = "#E8EEF4"
            self.text = "#16202A"
            self.muted = "#536273"
            self.border = "#B8C4D0"
            self.entry = "#FFFFFF"
            self.primary = "#0B63CE"
            self.info = "#007C91"
            self.success = "#16803A"
            self.warning = "#A15C00"
            self.danger = "#B42318"
            self.display = "#071A26"
            self.display_text = "#63FFB0"
            self.display_alt = "#0A2030"
            self.selection = "#B9D7FF"
        else:
            self.window = "#111820"
            self.panel = "#18232E"
            self.panel_alt = "#22313E"
            self.text = "#E9F0F6"
            self.muted = "#A9B7C4"
            self.border = "#3A4B59"
            self.entry = "#101820"
            self.primary = "#3B8EEA"
            self.info = "#23AFC2"
            self.success = "#38A169"
            self.warning = "#ECC94B"
            self.danger = "#E53E3E"
            self.display = "#071017"
            self.display_text = "#69FFB4"
            self.display_alt = "#091823"
            self.selection = "#244E78"


class Fluke45LoggerApp(tk.Tk):
    """Main Windows desktop interface for Fluke 45 acquisition."""

    def __init__(self, start_hidden: bool = False) -> None:
        """Initialize the standard Tkinter application window.

        Args:
            start_hidden: Hide the window during startup smoke tests.
        """
        configure_tk_runtime()
        super().__init__()
        if start_hidden:
            self.withdraw()
        self._config = load_config()
        self._palette = UiPalette(self._config.appearance)

        self.title(f"{APP_TITLE} v{__version__}")
        self.geometry("1180x780")
        self.minsize(980, 700)
        self.protocol("WM_DELETE_WINDOW", self._request_close)

        self._event_queue: queue.Queue[WorkerEvent] = queue.Queue()
        self._worker: InstrumentWorker | None = None
        self._connected = False
        self._logging_active = False
        self._monitoring_active = False
        self._last_csv_path: Path | None = None
        self._session_start_time: datetime | None = None
        self._error_count = 0

        self._create_variables()
        self._configure_styles()
        self._build_menu()
        self._build_layout()
        self._refresh_ports()
        self._update_controls()
        self.after(100, self._process_worker_events)
        self.after(250, self._update_elapsed_display)

    def _create_variables(self) -> None:
        """Create all Tkinter variables used by the interface."""
        self.port_var = tk.StringVar(value=self._config.port)
        self.baud_var = tk.StringVar(value=str(self._config.baud_rate))
        self.parity_var = tk.StringVar(value=self._config.parity)
        self.output_dir_var = tk.StringVar(
            value=self._config.output_directory
        )
        self.test_name_var = tk.StringVar(value="Measurement")
        self.live_interval_var = tk.StringVar(
            value=f"{self._config.live_interval_s:g}"
        )
        self.interval_var = tk.StringVar(
            value=f"{self._config.sample_interval_s:g}"
        )
        self.duration_var = tk.StringVar(
            value=f"{self._config.duration_minutes:g}"
        )
        self.rate_var = tk.StringVar(value=self._config.meter_rate)
        self.connection_status_var = tk.StringVar(value="DISCONNECTED")
        self.instrument_var = tk.StringVar(value="No instrument connected")
        self.primary_value_var = tk.StringVar(value="---")
        self.primary_unit_var = tk.StringVar(value="")
        self.secondary_value_var = tk.StringVar(value="---")
        self.secondary_unit_var = tk.StringVar(value="")
        self.sample_count_var = tk.StringVar(value="0")
        self.elapsed_var = tk.StringVar(value="00:00:00")
        self.error_count_var = tk.StringVar(value="0")
        self.csv_path_var = tk.StringVar(value="No CSV file active")

    def _configure_styles(self) -> None:
        """Configure a high-contrast ttk theme using standard Tkinter."""
        palette = self._palette
        self.configure(background=palette.window)
        style = ttk.Style(self)
        available = style.theme_names()
        if "clam" in available:
            style.theme_use("clam")

        style.configure(
            ".",
            background=palette.panel,
            foreground=palette.text,
            fieldbackground=palette.entry,
            bordercolor=palette.border,
            lightcolor=palette.border,
            darkcolor=palette.border,
            insertcolor=palette.text,
            selectbackground=palette.selection,
            selectforeground=palette.text,
            font=("Segoe UI", 10),
        )
        style.configure("App.TFrame", background=palette.window)
        style.configure("Panel.TFrame", background=palette.panel)
        style.configure("Card.TFrame", background=palette.panel_alt)
        style.configure(
            "Card.TLabel",
            background=palette.panel_alt,
            foreground=palette.text,
        )
        style.configure(
            "TLabel",
            background=palette.panel,
            foreground=palette.text,
        )
        style.configure(
            "Muted.TLabel",
            background=palette.panel,
            foreground=palette.muted,
        )
        style.configure(
            "Title.TLabel",
            background=palette.window,
            foreground=palette.text,
            font=("Segoe UI", 22, "bold"),
        )
        style.configure(
            "Subtitle.TLabel",
            background=palette.window,
            foreground=palette.muted,
        )
        style.configure(
            "StatusDanger.TLabel",
            background=palette.danger,
            foreground="#FFFFFF",
            padding=(14, 8),
            font=("Segoe UI", 10, "bold"),
        )
        style.configure(
            "StatusWarning.TLabel",
            background=palette.warning,
            foreground="#101010",
            padding=(14, 8),
            font=("Segoe UI", 10, "bold"),
        )
        style.configure(
            "StatusSuccess.TLabel",
            background=palette.success,
            foreground="#FFFFFF",
            padding=(14, 8),
            font=("Segoe UI", 10, "bold"),
        )
        style.configure(
            "TLabelframe",
            background=palette.panel,
            bordercolor=palette.border,
            relief="solid",
            borderwidth=1,
        )
        style.configure(
            "TLabelframe.Label",
            background=palette.panel,
            foreground=palette.text,
            font=("Segoe UI", 10, "bold"),
        )
        style.configure(
            "TEntry",
            fieldbackground=palette.entry,
            foreground=palette.text,
            insertcolor=palette.text,
            bordercolor=palette.border,
            padding=6,
        )
        style.configure(
            "TCombobox",
            fieldbackground=palette.entry,
            background=palette.panel_alt,
            foreground=palette.text,
            arrowcolor=palette.text,
            bordercolor=palette.border,
            padding=5,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", palette.entry)],
            foreground=[("readonly", palette.text)],
            selectbackground=[("readonly", palette.entry)],
            selectforeground=[("readonly", palette.text)],
        )
        self._configure_button_style(
            style,
            "Primary.TButton",
            palette.primary,
            "#FFFFFF",
        )
        self._configure_button_style(
            style,
            "Info.TButton",
            palette.info,
            "#FFFFFF",
        )
        self._configure_button_style(
            style,
            "Success.TButton",
            palette.success,
            "#FFFFFF",
        )
        self._configure_button_style(
            style,
            "Danger.TButton",
            palette.danger,
            "#FFFFFF",
        )
        self._configure_button_style(
            style,
            "Secondary.TButton",
            palette.panel_alt,
            palette.text,
        )
        style.configure(
            "TButton",
            padding=(10, 7),
            font=("Segoe UI", 9, "bold"),
        )
        style.configure(
            "Treeview",
            background=palette.panel,
            fieldbackground=palette.panel,
            foreground=palette.text,
        )

    @staticmethod
    def _configure_button_style(
        style: ttk.Style,
        style_name: str,
        background: str,
        foreground: str,
    ) -> None:
        """Configure one colored button style.

        Args:
            style: Active ttk style manager.
            style_name: Name assigned to the custom button style.
            background: Normal button background color.
            foreground: Normal button text color.
        """
        style.configure(
            style_name,
            background=background,
            foreground=foreground,
            padding=(10, 7),
            borderwidth=0,
            font=("Segoe UI", 9, "bold"),
        )
        style.map(
            style_name,
            background=[
                ("disabled", "#58636E"),
                ("pressed", background),
                ("active", background),
            ],
            foreground=[("disabled", "#C0C7CE")],
        )

    def _build_menu(self) -> None:
        """Build the application menu bar."""
        menu_bar = tk.Menu(self)
        view_menu = tk.Menu(menu_bar, tearoff=False)
        view_menu.add_command(
            label="Toggle Light or Dark Appearance",
            command=self._toggle_appearance,
        )
        menu_bar.add_cascade(label="View", menu=view_menu)

        help_menu = tk.Menu(menu_bar, tearoff=False)
        help_menu.add_command(
            label="About",
            command=self._show_about,
        )
        menu_bar.add_cascade(label="Help", menu=help_menu)
        self.configure(menu=menu_bar)

    def _build_layout(self) -> None:
        """Build and arrange all visual controls."""
        container = ttk.Frame(self, padding=12, style="App.TFrame")
        container.pack(fill=tk.BOTH, expand=True)
        container.columnconfigure(0, weight=1)
        container.columnconfigure(1, weight=2)
        container.rowconfigure(1, weight=1)
        container.rowconfigure(3, weight=1)

        self._build_header(container)
        self._build_connection_panel(container)
        self._build_measurement_panel(container)
        self._build_session_panel(container)
        self._build_event_panel(container)

    def _build_header(self, parent: ttk.Frame) -> None:
        """Build the title and connection status header.

        Args:
            parent: Parent layout frame.
        """
        header = ttk.Frame(parent, padding=(4, 4, 4, 12))
        header.configure(style="App.TFrame")
        header.grid(row=0, column=0, columnspan=2, sticky="ew")
        header.columnconfigure(0, weight=1)

        ttk.Label(
            header,
            text=APP_TITLE,
            style="Title.TLabel",
        ).grid(row=0, column=0, sticky="w")
        ttk.Label(
            header,
            text=(
                "RS-232 acquisition, dual-display monitoring, and "
                "timestamped CSV logging"
            ),
            style="Subtitle.TLabel",
        ).grid(row=1, column=0, sticky="w")

        self.status_label = ttk.Label(
            header,
            textvariable=self.connection_status_var,
            style="StatusDanger.TLabel",
        )
        self.status_label.grid(row=0, column=1, rowspan=2, sticky="e")

    def _build_connection_panel(self, parent: ttk.Frame) -> None:
        """Build serial connection controls.

        Args:
            parent: Parent layout frame.
        """
        panel = ttk.LabelFrame(
            parent,
            text="1. Serial Connection",
            padding=12,
        )
        panel.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        panel.columnconfigure(1, weight=1)

        ttk.Label(panel, text="COM port").grid(
            row=0,
            column=0,
            sticky="w",
            pady=5,
        )
        self.port_combo = ttk.Combobox(
            panel,
            textvariable=self.port_var,
            state="readonly",
        )
        self.port_combo.grid(row=0, column=1, sticky="ew", pady=5)
        self.refresh_button = ttk.Button(
            panel,
            text="Refresh",
            command=self._refresh_ports,
            style="Secondary.TButton",
        )
        self.refresh_button.grid(row=0, column=2, padx=(8, 0), pady=5)

        ttk.Label(panel, text="Baud rate").grid(
            row=1,
            column=0,
            sticky="w",
            pady=5,
        )
        self.baud_combo = ttk.Combobox(
            panel,
            textvariable=self.baud_var,
            values=COMMON_BAUD_RATES,
            state="readonly",
        )
        self.baud_combo.grid(
            row=1,
            column=1,
            columnspan=2,
            sticky="ew",
        )

        ttk.Label(panel, text="Parity").grid(
            row=2,
            column=0,
            sticky="w",
            pady=5,
        )
        self.parity_combo = ttk.Combobox(
            panel,
            textvariable=self.parity_var,
            values=[mode.value for mode in ParityMode],
            state="readonly",
        )
        self.parity_combo.grid(
            row=2,
            column=1,
            columnspan=2,
            sticky="ew",
        )

        self.connect_button = ttk.Button(
            panel,
            text="Connect and Identify",
            command=self._connect,
            style="Success.TButton",
        )
        self.connect_button.grid(
            row=3,
            column=0,
            columnspan=2,
            sticky="ew",
            pady=(12, 5),
        )
        self.disconnect_button = ttk.Button(
            panel,
            text="Disconnect",
            command=self._disconnect,
            style="Danger.TButton",
        )
        self.disconnect_button.grid(
            row=3,
            column=2,
            sticky="ew",
            padx=(8, 0),
            pady=(12, 5),
        )

        identity_box = ttk.Frame(
            panel,
            padding=10,
            style="Card.TFrame",
        )
        identity_box.grid(
            row=4,
            column=0,
            columnspan=3,
            sticky="ew",
            pady=(12, 0),
        )
        identity_box.columnconfigure(0, weight=1)
        ttk.Label(
            identity_box,
            text="Instrument",
            style="Card.TLabel",
            font=("Segoe UI", 9, "bold"),
        ).grid(row=0, column=0, sticky="w")
        ttk.Label(
            identity_box,
            textvariable=self.instrument_var,
            style="Card.TLabel",
            wraplength=390,
        ).grid(row=1, column=0, sticky="w")

        help_text = (
            "Recommended starting point: 9600 baud, no parity, "
            "one stop bit, and RS-232 echo OFF."
        )
        ttk.Label(
            panel,
            text=help_text,
            style="Muted.TLabel",
            wraplength=390,
        ).grid(
            row=5,
            column=0,
            columnspan=3,
            sticky="w",
            pady=(12, 0),
        )

    def _build_measurement_panel(self, parent: ttk.Frame) -> None:
        """Build live primary and secondary display cards.

        Args:
            parent: Parent layout frame.
        """
        panel = ttk.LabelFrame(
            parent,
            text="2. Live Meter Display",
            padding=12,
        )
        panel.grid(row=1, column=1, sticky="nsew", padx=(8, 0))
        panel.columnconfigure(0, weight=1)
        panel.columnconfigure(1, weight=1)
        panel.rowconfigure(0, weight=1)

        primary = tk.Frame(
            panel,
            background=self._palette.display,
            highlightbackground=self._palette.primary,
            highlightthickness=1,
            padx=18,
            pady=18,
        )
        primary.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        primary.columnconfigure(0, weight=1)
        tk.Label(
            primary,
            text="PRIMARY DISPLAY",
            background=self._palette.display,
            foreground=self._palette.muted,
            font=("Segoe UI", 11, "bold"),
        ).grid(row=0, column=0, sticky="w")
        tk.Label(
            primary,
            textvariable=self.primary_value_var,
            background=self._palette.display,
            foreground=self._palette.display_text,
            font=("Consolas", 30, "bold"),
        ).grid(row=1, column=0, sticky="e", pady=(20, 4))
        tk.Label(
            primary,
            textvariable=self.primary_unit_var,
            background=self._palette.display,
            foreground=self._palette.display_text,
            font=("Segoe UI", 14, "bold"),
        ).grid(row=2, column=0, sticky="e")

        secondary = tk.Frame(
            panel,
            background=self._palette.display_alt,
            highlightbackground=self._palette.info,
            highlightthickness=1,
            padx=18,
            pady=18,
        )
        secondary.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        secondary.columnconfigure(0, weight=1)
        tk.Label(
            secondary,
            text="SECONDARY DISPLAY",
            background=self._palette.display_alt,
            foreground=self._palette.muted,
            font=("Segoe UI", 11, "bold"),
        ).grid(row=0, column=0, sticky="w")
        tk.Label(
            secondary,
            textvariable=self.secondary_value_var,
            background=self._palette.display_alt,
            foreground=self._palette.display_text,
            font=("Consolas", 30, "bold"),
        ).grid(row=1, column=0, sticky="e", pady=(20, 4))
        tk.Label(
            secondary,
            textvariable=self.secondary_unit_var,
            background=self._palette.display_alt,
            foreground=self._palette.display_text,
            font=("Segoe UI", 14, "bold"),
        ).grid(row=2, column=0, sticky="e")

        live_controls = ttk.Frame(panel)
        live_controls.grid(
            row=1,
            column=0,
            columnspan=2,
            sticky="ew",
            pady=(12, 0),
        )
        live_controls.columnconfigure(3, weight=1)
        live_controls.columnconfigure(4, weight=1)
        live_controls.columnconfigure(5, weight=1)

        ttk.Label(live_controls, text="Live interval (s)").grid(
            row=0,
            column=0,
            sticky="w",
        )
        self.live_interval_entry = ttk.Entry(
            live_controls,
            textvariable=self.live_interval_var,
            width=10,
        )
        self.live_interval_entry.grid(
            row=0,
            column=1,
            sticky="w",
            padx=(8, 12),
        )
        self.single_read_button = ttk.Button(
            live_controls,
            text="Acquire Single Reading",
            command=self._single_reading,
            style="Info.TButton",
        )
        self.single_read_button.grid(
            row=0,
            column=3,
            sticky="ew",
            padx=(0, 6),
        )
        self.start_monitor_button = ttk.Button(
            live_controls,
            text="START LIVE DISPLAY",
            command=self._start_monitoring,
            style="Success.TButton",
        )
        self.start_monitor_button.grid(
            row=0,
            column=4,
            sticky="ew",
            padx=6,
        )
        self.stop_monitor_button = ttk.Button(
            live_controls,
            text="STOP LIVE DISPLAY",
            command=self._stop_monitoring,
            style="Danger.TButton",
        )
        self.stop_monitor_button.grid(
            row=0,
            column=5,
            sticky="ew",
            padx=(6, 0),
        )

    def _build_session_panel(self, parent: ttk.Frame) -> None:
        """Build CSV session settings and status controls.

        Args:
            parent: Parent layout frame.
        """
        panel = ttk.LabelFrame(
            parent,
            text="3. CSV Logging Session",
            padding=12,
        )
        panel.grid(
            row=2,
            column=0,
            columnspan=2,
            sticky="ew",
            pady=(12, 0),
        )
        panel.columnconfigure(1, weight=1)
        panel.columnconfigure(4, weight=1)

        ttk.Label(panel, text="Test name").grid(
            row=0,
            column=0,
            sticky="w",
        )
        self.test_name_entry = ttk.Entry(
            panel,
            textvariable=self.test_name_var,
        )
        self.test_name_entry.grid(
            row=0,
            column=1,
            sticky="ew",
            padx=(8, 16),
        )

        ttk.Label(panel, text="Output folder").grid(
            row=0,
            column=2,
            sticky="w",
        )
        self.output_entry = ttk.Entry(
            panel,
            textvariable=self.output_dir_var,
        )
        self.output_entry.grid(
            row=0,
            column=3,
            columnspan=2,
            sticky="ew",
            padx=(8, 8),
        )
        self.browse_button = ttk.Button(
            panel,
            text="Browse",
            command=self._browse_output_directory,
            style="Secondary.TButton",
        )
        self.browse_button.grid(row=0, column=5, sticky="ew")

        ttk.Label(panel, text="CSV interval (s)").grid(
            row=1,
            column=0,
            sticky="w",
            pady=(10, 0),
        )
        self.interval_entry = ttk.Entry(
            panel,
            textvariable=self.interval_var,
            width=12,
        )
        self.interval_entry.grid(
            row=1,
            column=1,
            sticky="w",
            padx=(8, 16),
            pady=(10, 0),
        )

        ttk.Label(panel, text="Duration (min, 0 = continuous)").grid(
            row=1,
            column=2,
            sticky="w",
            pady=(10, 0),
        )
        self.duration_entry = ttk.Entry(
            panel,
            textvariable=self.duration_var,
            width=14,
        )
        self.duration_entry.grid(
            row=1,
            column=3,
            sticky="w",
            padx=(8, 16),
            pady=(10, 0),
        )

        ttk.Label(panel, text="Meter rate").grid(
            row=1,
            column=4,
            sticky="e",
            pady=(10, 0),
        )
        self.rate_combo = ttk.Combobox(
            panel,
            textvariable=self.rate_var,
            values=[rate.value for rate in MeterRate],
            state="readonly",
            width=12,
        )
        self.rate_combo.grid(
            row=1,
            column=5,
            sticky="ew",
            padx=(8, 0),
            pady=(10, 0),
        )

        controls = ttk.Frame(panel)
        controls.grid(
            row=2,
            column=0,
            columnspan=6,
            sticky="ew",
            pady=(14, 0),
        )
        for index in range(3):
            controls.columnconfigure(index, weight=1)

        self.start_button = ttk.Button(
            controls,
            text="START CSV LOGGING",
            command=self._start_logging,
            style="Success.TButton",
        )
        self.start_button.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.stop_button = ttk.Button(
            controls,
            text="STOP LOGGING",
            command=self._stop_logging,
            style="Danger.TButton",
        )
        self.stop_button.grid(row=0, column=1, sticky="ew", padx=6)
        self.open_folder_button = ttk.Button(
            controls,
            text="Open Output Folder",
            command=self._open_output_directory,
            style="Secondary.TButton",
        )
        self.open_folder_button.grid(
            row=0,
            column=2,
            sticky="ew",
            padx=(6, 0),
        )

        stats = ttk.Frame(panel, padding=(0, 14, 0, 0))
        stats.grid(row=3, column=0, columnspan=6, sticky="ew")
        for index in range(4):
            stats.columnconfigure(index, weight=1)
        self._add_stat(stats, 0, "Samples", self.sample_count_var)
        self._add_stat(stats, 1, "Elapsed", self.elapsed_var)
        self._add_stat(stats, 2, "Errors", self.error_count_var)
        self._add_stat(stats, 3, "CSV", self.csv_path_var)

    def _build_event_panel(self, parent: ttk.Frame) -> None:
        """Build the application event-log display.

        Args:
            parent: Parent layout frame.
        """
        panel = ttk.LabelFrame(
            parent,
            text="4. Application Event Log",
            padding=8,
        )
        panel.grid(
            row=3,
            column=0,
            columnspan=2,
            sticky="nsew",
            pady=(12, 0),
        )
        self.event_text = scrolledtext.ScrolledText(
            panel,
            height=8,
            state="disabled",
            wrap="word",
            font=("Consolas", 9),
            background=self._palette.entry,
            foreground=self._palette.text,
            insertbackground=self._palette.text,
            selectbackground=self._palette.selection,
            relief="flat",
            borderwidth=0,
        )
        self.event_text.pack(fill=tk.BOTH, expand=True)
        self._append_event("Application ready.")

    def _add_stat(
        self,
        parent: ttk.Frame,
        column: int,
        label_text: str,
        value_var: tk.StringVar,
    ) -> None:
        """Add a compact session-statistic card.

        Args:
            parent: Parent frame.
            column: Grid column index.
            label_text: Statistic label.
            value_var: Tk variable containing the displayed value.
        """
        card = tk.Frame(
            parent,
            background=self._palette.panel_alt,
            highlightbackground=self._palette.border,
            highlightthickness=1,
            padx=8,
            pady=8,
        )
        card.grid(
            row=0,
            column=column,
            sticky="ew",
            padx=(0 if column == 0 else 4, 0),
        )
        tk.Label(
            card,
            text=label_text,
            background=self._palette.panel_alt,
            foreground=self._palette.muted,
            font=("Segoe UI", 8, "bold"),
        ).pack(anchor="w")
        tk.Label(
            card,
            textvariable=value_var,
            background=self._palette.panel_alt,
            foreground=self._palette.text,
            wraplength=260,
        ).pack(anchor="w")

    def _refresh_ports(self) -> None:
        """Refresh the available Windows COM-port list."""
        try:
            ports = sorted(
                port.device
                for port in serial.tools.list_ports.comports()
            )
        except (serial.SerialException, OSError) as exc:
            self._show_error("COM Port Scan Failed", str(exc))
            return

        self.port_combo.configure(values=ports)
        current = self.port_var.get().strip()
        if current not in ports:
            self.port_var.set(ports[0] if ports else "")
        self._append_event(
            f"COM-port scan completed: {len(ports)} port(s) found."
        )

    def _connect(self) -> None:
        """Validate settings and start the instrument worker."""
        if self._worker is not None and self._worker.is_alive():
            return
        try:
            settings = self._read_serial_settings()
        except ValueError as exc:
            self._show_error("Invalid Serial Settings", str(exc))
            return

        self._worker = InstrumentWorker(settings, self._event_queue)
        self._connected = False
        self.connection_status_var.set("CONNECTING")
        self.status_label.configure(style="StatusWarning.TLabel")
        self._update_controls()
        self._worker.start()
        self._append_event(
            f"Connecting to {settings.port} at {settings.baud_rate} baud."
        )

    def _disconnect(self) -> None:
        """Request a clean session stop and serial disconnect."""
        worker = self._worker
        if worker is None:
            return
        worker.submit(
            WorkerCommand(kind=WorkerCommandKind.DISCONNECT)
        )
        self._append_event("Disconnect requested.")

    def _single_reading(self) -> None:
        """Request one immediate display reading."""
        worker = self._worker
        if worker is None or not self._connected:
            return
        worker.submit(
            WorkerCommand(kind=WorkerCommandKind.SINGLE_READING)
        )

    def _start_monitoring(self) -> None:
        """Validate and start continuous live-display acquisition."""
        worker = self._worker
        if worker is None or not self._connected:
            return
        try:
            settings = self._read_monitor_settings()
        except ValueError as exc:
            self._show_error("Invalid Live Display Settings", str(exc))
            return
        worker.submit(
            WorkerCommand(
                kind=WorkerCommandKind.START_MONITOR,
                payload=settings,
            )
        )
        self._append_event("Live display start requested.")

    def _stop_monitoring(self) -> None:
        """Request a clean stop for continuous live acquisition."""
        worker = self._worker
        if worker is None:
            return
        worker.submit(
            WorkerCommand(kind=WorkerCommandKind.STOP_MONITOR)
        )

    def _start_logging(self) -> None:
        """Validate session settings and request CSV logging."""
        worker = self._worker
        if worker is None or not self._connected:
            return
        try:
            settings = self._read_session_settings()
        except ValueError as exc:
            self._show_error("Invalid Session Settings", str(exc))
            return

        worker.submit(
            WorkerCommand(
                kind=WorkerCommandKind.START_SESSION,
                payload=settings,
            )
        )
        self._append_event("CSV logging start requested.")

    def _stop_logging(self) -> None:
        """Request a clean stop for the active CSV session."""
        worker = self._worker
        if worker is None:
            return
        worker.submit(
            WorkerCommand(kind=WorkerCommandKind.STOP_SESSION)
        )

    def _browse_output_directory(self) -> None:
        """Open a folder selector for CSV output."""
        selected = filedialog.askdirectory(
            parent=self,
            initialdir=self.output_dir_var.get() or str(Path.home()),
            title="Select Fluke 45 CSV Output Folder",
            mustexist=False,
        )
        if selected:
            self.output_dir_var.set(selected)

    def _open_output_directory(self) -> None:
        """Open the selected output folder in Windows Explorer."""
        path_text = self.output_dir_var.get().strip()
        if not path_text:
            return
        path = Path(path_text).expanduser()
        try:
            path.mkdir(parents=True, exist_ok=True)
            os.startfile(path)  # type: ignore[attr-defined]
        except OSError as exc:
            self._show_error("Open Folder Failed", str(exc))

    def _read_serial_settings(self) -> SerialSettings:
        """Validate serial controls and create typed settings.

        Returns:
            Validated serial connection settings.

        Raises:
            ValueError: If a required serial setting is invalid.
        """
        port = self.port_var.get().strip()
        if not port:
            raise ValueError("Select a COM port.")
        try:
            baud_rate = int(self.baud_var.get().strip())
        except ValueError as exc:
            raise ValueError("Baud rate must be an integer.") from exc
        if baud_rate not in FLUKE45_BAUD_RATES:
            supported = ", ".join(COMMON_BAUD_RATES)
            raise ValueError(
                f"Fluke 45 baud rate must be one of: {supported}."
            )
        try:
            parity = ParityMode(self.parity_var.get())
        except ValueError as exc:
            raise ValueError("Select None, Even, or Odd parity.") from exc
        return SerialSettings(
            port=port,
            baud_rate=baud_rate,
            parity=parity,
        )

    def _read_monitor_settings(self) -> MonitorSettings:
        """Validate live-display controls and create typed settings.

        Returns:
            Validated continuous-monitoring settings.

        Raises:
            ValueError: If the live interval is invalid.
        """
        try:
            interval_s = float(self.live_interval_var.get().strip())
        except ValueError as exc:
            raise ValueError("Live interval must be numeric.") from exc
        if not (
            MIN_SAMPLE_INTERVAL_S
            <= interval_s
            <= MAX_SAMPLE_INTERVAL_S
        ):
            raise ValueError(
                "Live interval must be between 0.05 and "
                "86400 seconds."
            )
        return MonitorSettings(sample_interval_s=interval_s)

    def _read_session_settings(self) -> SessionSettings:
        """Validate logging controls and create typed settings.

        Returns:
            Validated CSV session settings.

        Raises:
            ValueError: If a session value is invalid.
        """
        output_text = self.output_dir_var.get().strip()
        if not output_text:
            raise ValueError("Select an output folder.")
        try:
            interval_s = float(self.interval_var.get().strip())
        except ValueError as exc:
            raise ValueError("Sample interval must be numeric.") from exc
        if not (
            MIN_SAMPLE_INTERVAL_S
            <= interval_s
            <= MAX_SAMPLE_INTERVAL_S
        ):
            raise ValueError(
                "Sample interval must be between 0.05 and "
                "86400 seconds."
            )
        try:
            duration_minutes = float(self.duration_var.get().strip())
        except ValueError as exc:
            raise ValueError("Duration must be numeric.") from exc
        if not (
            0
            <= duration_minutes
            <= MAX_SESSION_DURATION_MINUTES
        ):
            raise ValueError(
                "Duration must be 0 to 525600 minutes."
            )
        try:
            meter_rate = MeterRate(self.rate_var.get())
        except ValueError as exc:
            raise ValueError("Select a supported meter rate.") from exc
        return SessionSettings(
            output_directory=Path(output_text).expanduser(),
            test_name=self.test_name_var.get(),
            sample_interval_s=interval_s,
            duration_minutes=duration_minutes,
            meter_rate=meter_rate,
        )

    def _process_worker_events(self) -> None:
        """Drain background events and update the Tkinter interface."""
        while True:
            try:
                event = self._event_queue.get_nowait()
            except queue.Empty:
                break
            self._handle_worker_event(event)
        self.after(100, self._process_worker_events)

    def _handle_worker_event(self, event: WorkerEvent) -> None:
        """Apply one worker event to GUI state.

        Args:
            event: Event produced by the instrument thread.
        """
        quiet_reading = event.kind in {
            EventKind.LIVE_READING,
            EventKind.READING,
        }
        if event.kind is EventKind.READING:
            quiet_reading = (
                isinstance(event.payload, MeterReading)
                and event.payload.sample_index > 0
            )
        if not quiet_reading:
            self._append_event(event.message)

        if event.kind is EventKind.CONNECTED:
            self._handle_connected(event.payload)
        elif event.kind is EventKind.CONNECTION_FAILED:
            self._connected = False
            self._worker = None
            self.connection_status_var.set("CONNECTION FAILED")
            self.status_label.configure(style="StatusDanger.TLabel")
            self._show_error("Fluke 45 Connection Failed", event.message)
        elif event.kind is EventKind.DISCONNECTED:
            self._connected = False
            self._monitoring_active = False
            self._logging_active = False
            self._worker = None
            self.connection_status_var.set("DISCONNECTED")
            self.instrument_var.set("No instrument connected")
            self.status_label.configure(style="StatusDanger.TLabel")
        elif event.kind is EventKind.MONITOR_STARTED:
            self._monitoring_active = True
        elif event.kind is EventKind.MONITOR_STOPPED:
            self._monitoring_active = False
        elif event.kind is EventKind.SESSION_STARTED:
            self._logging_active = True
            self._session_start_time = datetime.now().astimezone()
            self.sample_count_var.set("0")
            self.error_count_var.set("0")
            self._error_count = 0
            if isinstance(event.payload, Path):
                self._last_csv_path = event.payload
                self.csv_path_var.set(event.payload.name)
        elif event.kind is EventKind.SESSION_STOPPED:
            self._logging_active = False
            self._session_start_time = None
            if isinstance(event.payload, Path):
                self._last_csv_path = event.payload
                self.csv_path_var.set(event.payload.name)
        elif event.kind in {EventKind.LIVE_READING, EventKind.READING}:
            self._handle_reading(event.payload)
        elif event.kind is EventKind.ERROR:
            self._error_count += 1
            self.error_count_var.set(str(self._error_count))
        self._update_controls()

    def _handle_connected(self, payload: object | None) -> None:
        """Update interface state after successful identification.

        Args:
            payload: Expected ``DeviceIdentity`` payload.
        """
        if not isinstance(payload, DeviceIdentity):
            return
        self._connected = True
        self.connection_status_var.set("CONNECTED")
        self.status_label.configure(style="StatusSuccess.TLabel")
        self.instrument_var.set(
            f"{payload.manufacturer} {payload.model} | "
            f"Serial {payload.serial_number} | {payload.firmware}"
        )

    def _handle_reading(self, payload: object | None) -> None:
        """Display a primary and optional secondary reading.

        Args:
            payload: Expected ``MeterReading`` payload.
        """
        if not isinstance(payload, MeterReading):
            return
        self.primary_value_var.set(
            self._format_display_value(payload.primary.value)
        )
        self.primary_unit_var.set(payload.primary.unit)
        if payload.secondary is None:
            self.secondary_value_var.set("OFF")
            self.secondary_unit_var.set("")
        else:
            self.secondary_value_var.set(
                self._format_display_value(payload.secondary.value)
            )
            self.secondary_unit_var.set(payload.secondary.unit)
        if payload.sample_index > 0:
            self.sample_count_var.set(str(payload.sample_index))
            self.elapsed_var.set(
                self._format_elapsed(payload.elapsed_s)
            )

    def _update_elapsed_display(self) -> None:
        """Refresh elapsed time while a logging session is active."""
        if self._logging_active and self._session_start_time is not None:
            elapsed = (
                datetime.now().astimezone() - self._session_start_time
            ).total_seconds()
            self.elapsed_var.set(self._format_elapsed(elapsed))
        self.after(250, self._update_elapsed_display)

    def _update_controls(self) -> None:
        """Enable or disable controls to match application state."""
        worker_alive = self._worker is not None and self._worker.is_alive()
        connecting = worker_alive and not self._connected
        connection_state = "disabled" if worker_alive else "normal"
        self.connect_button.configure(state=connection_state)
        self.refresh_button.configure(state=connection_state)
        self.port_combo.configure(
            state="disabled" if worker_alive else "readonly"
        )
        self.baud_combo.configure(
            state="disabled" if worker_alive else "readonly"
        )
        self.parity_combo.configure(
            state="disabled" if worker_alive else "readonly"
        )
        self.disconnect_button.configure(
            state="normal" if worker_alive else "disabled"
        )

        connected_idle = (
            self._connected
            and not connecting
            and not self._monitoring_active
            and not self._logging_active
        )
        self.single_read_button.configure(
            state="normal" if connected_idle else "disabled"
        )
        self.start_monitor_button.configure(
            state="normal" if connected_idle else "disabled"
        )
        self.stop_monitor_button.configure(
            state="normal" if self._monitoring_active else "disabled"
        )
        self.live_interval_entry.configure(
            state=(
                "disabled"
                if self._monitoring_active or self._logging_active
                else "normal"
            )
        )
        self.start_button.configure(
            state="normal" if connected_idle else "disabled"
        )
        self.stop_button.configure(
            state="normal" if self._logging_active else "disabled"
        )
        session_input_state = (
            "disabled" if self._logging_active else "normal"
        )
        self.test_name_entry.configure(state=session_input_state)
        self.output_entry.configure(state=session_input_state)
        self.browse_button.configure(state=session_input_state)
        self.interval_entry.configure(state=session_input_state)
        self.duration_entry.configure(state=session_input_state)
        self.rate_combo.configure(
            state=(
                "disabled" if self._logging_active else "readonly"
            )
        )

    def _append_event(self, message: str) -> None:
        """Append a timestamped line to the visual event log.

        Args:
            message: Human-readable event text.
        """
        timestamp = datetime.now().astimezone().strftime("%H:%M:%S")
        line = f"[{timestamp}] {message}\n"
        self.event_text.configure(state="normal")
        self.event_text.insert(tk.END, line)
        self._trim_event_log()
        self.event_text.see(tk.END)
        self.event_text.configure(state="disabled")
        LOGGER.info(message)

    def _trim_event_log(self) -> None:
        """Remove the oldest visual events above the configured limit."""
        final_index = self.event_text.index("end-1c")
        final_line = int(final_index.split(".", maxsplit=1)[0])
        excess_lines = final_line - MAX_EVENT_LOG_LINES
        if excess_lines > 0:
            self.event_text.delete("1.0", f"{excess_lines + 1}.0")

    def _toggle_appearance(self) -> None:
        """Toggle appearance and restart the application window."""
        new_value = (
            "light" if self._palette.appearance == "dark" else "dark"
        )
        self._config.appearance = new_value
        try:
            save_config(self._config)
        except OSError as exc:
            self._show_error("Appearance Save Failed", str(exc))
            return
        self._palette.appearance = new_value
        messagebox.showinfo(
            "Appearance Changed",
            "Restart the application to apply the new appearance.",
            parent=self,
        )

    def _show_about(self) -> None:
        """Display application identity and dependency information."""
        messagebox.showinfo(
            "About Fluke 45 Logger",
            (
                f"{APP_TITLE}\n"
                f"Version {__version__}\n\n"
                "GUI: Python standard Tkinter and ttk\n"
                "Serial communication: pySerial\n"
                "Output: Timestamped CSV"
            ),
            parent=self,
        )

    def _show_error(self, title: str, message: str) -> None:
        """Display a modal error message.

        Args:
            title: Dialog title.
            message: Error details.
        """
        messagebox.showerror(title, message, parent=self)

    def _save_preferences(self) -> None:
        """Persist non-sensitive GUI settings for the next run."""
        try:
            baud_rate = int(self.baud_var.get())
        except ValueError:
            baud_rate = 9600
        try:
            live_interval_s = float(self.live_interval_var.get())
        except ValueError:
            live_interval_s = 1.0
        try:
            interval_s = float(self.interval_var.get())
        except ValueError:
            interval_s = 1.0
        try:
            duration_minutes = float(self.duration_var.get())
        except ValueError:
            duration_minutes = 0.0

        config = AppConfig(
            port=self.port_var.get().strip(),
            baud_rate=baud_rate,
            parity=self.parity_var.get(),
            output_directory=self.output_dir_var.get().strip(),
            live_interval_s=live_interval_s,
            sample_interval_s=interval_s,
            duration_minutes=duration_minutes,
            meter_rate=self.rate_var.get(),
            appearance=self._palette.appearance,
        )
        try:
            save_config(config)
        except OSError as exc:
            LOGGER.warning("Could not save preferences: %s", exc)

    def _request_close(self) -> None:
        """Stop active work, save preferences, and close the window."""
        self._save_preferences()
        worker = self._worker
        if worker is not None and worker.is_alive():
            worker.submit(
                WorkerCommand(kind=WorkerCommandKind.DISCONNECT)
            )
            worker.join(timeout=5.5)
        self.destroy()

    @staticmethod
    def _format_display_value(value: float) -> str:
        """Format a meter value for the large live display.

        Args:
            value: Numeric meter value.

        Returns:
            Compact engineering-style value text.
        """
        return format(value, ".8g")

    @staticmethod
    def _format_elapsed(elapsed_s: float) -> str:
        """Convert seconds to an ``HH:MM:SS`` display.

        Args:
            elapsed_s: Non-negative elapsed time.

        Returns:
            Zero-padded duration text.
        """
        whole_seconds = max(0, int(elapsed_s))
        hours, remainder = divmod(whole_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def smoke_test_application() -> int:
    """Construct and destroy the GUI without entering its event loop.

    Returns:
        Process exit status code.
    """
    try:
        application = Fluke45LoggerApp(start_hidden=True)
        application.update_idletasks()
        application.destroy()
    except (tk.TclError, TkRuntimeError) as exc:
        LOGGER.critical("GUI smoke test failed: %s", exc)
        return 2
    return 0


def run_application() -> int:
    """Launch the graphical application.

    Returns:
        Process exit status code.
    """
    try:
        application = Fluke45LoggerApp()
        application.mainloop()
    except (tk.TclError, TkRuntimeError) as exc:
        LOGGER.critical("GUI startup failed: %s", exc)
        return 2
    return 0

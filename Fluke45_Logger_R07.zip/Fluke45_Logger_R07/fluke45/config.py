"""Persistent application configuration and path management."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path

from fluke45.models import (
    FLUKE45_BAUD_RATES,
    MAX_SAMPLE_INTERVAL_S,
    MAX_SESSION_DURATION_MINUTES,
    MIN_SAMPLE_INTERVAL_S,
    MeterRate,
    ParityMode,
)

APP_DIRECTORY_NAME = "Fluke45Logger"
CONFIG_FILE_NAME = "config.json"
DEFAULT_BAUD_RATE = 9600
DEFAULT_LIVE_INTERVAL_S = 1.0
DEFAULT_SAMPLE_INTERVAL_S = 1.0
DEFAULT_DURATION_MINUTES = 0.0
DEFAULT_APPEARANCE = "dark"
SUPPORTED_APPEARANCES = {"dark", "light"}


@dataclass(slots=True)
class AppConfig:
    """User interface settings persisted between application runs.

    Args:
        port: Last selected serial port.
        baud_rate: Last selected baud rate.
        parity: Last selected parity label.
        output_directory: Last selected CSV output directory.
        live_interval_s: Last selected live display interval.
        sample_interval_s: Last selected CSV sample interval.
        duration_minutes: Last selected CSV duration in minutes.
        meter_rate: Last selected meter rate label.
        appearance: Standard Tkinter dark or light appearance.
    """

    port: str = ""
    baud_rate: int = DEFAULT_BAUD_RATE
    parity: str = ParityMode.NONE.value
    output_directory: str = ""
    live_interval_s: float = DEFAULT_LIVE_INTERVAL_S
    sample_interval_s: float = DEFAULT_SAMPLE_INTERVAL_S
    duration_minutes: float = DEFAULT_DURATION_MINUTES
    meter_rate: str = MeterRate.SLOW.value
    appearance: str = DEFAULT_APPEARANCE


def get_local_app_directory() -> Path:
    """Return the per-user application data directory.

    Returns:
        A Windows-local application path with a portable fallback.
    """
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        return Path(local_app_data) / APP_DIRECTORY_NAME
    return Path.home() / ".fluke45_logger"


def get_default_output_directory() -> Path:
    """Return the default measurement output directory.

    Returns:
        A folder inside the current user's Documents directory.
    """
    return Path.home() / "Documents" / "Fluke45_Logs"


def get_config_path() -> Path:
    """Return the application configuration file path.

    Returns:
        The path to ``config.json``.
    """
    return get_local_app_directory() / CONFIG_FILE_NAME


def load_config() -> AppConfig:
    """Load persistent application configuration.

    Returns:
        A validated configuration or defaults when no file exists.
    """
    path = get_config_path()
    if not path.exists():
        config = AppConfig()
        config.output_directory = str(get_default_output_directory())
        return config

    try:
        raw_data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        config = AppConfig()
        config.output_directory = str(get_default_output_directory())
        return config

    if not isinstance(raw_data, dict):
        config = AppConfig()
        config.output_directory = str(get_default_output_directory())
        return config

    config = AppConfig()
    config.port = str(raw_data.get("port", ""))
    requested_baud = _safe_int(
        raw_data.get("baud_rate"),
        DEFAULT_BAUD_RATE,
    )
    config.baud_rate = (
        requested_baud
        if requested_baud in FLUKE45_BAUD_RATES
        else DEFAULT_BAUD_RATE
    )
    config.parity = _enum_value_or_default(
        raw_data.get("parity"),
        ParityMode,
        ParityMode.NONE.value,
    )
    requested_output = str(
        raw_data.get(
            "output_directory",
            str(get_default_output_directory()),
        )
    ).strip()
    config.output_directory = (
        requested_output
        if requested_output
        else str(get_default_output_directory())
    )
    config.live_interval_s = _validated_interval(
        raw_data.get("live_interval_s"),
        DEFAULT_LIVE_INTERVAL_S,
    )
    config.sample_interval_s = _validated_interval(
        raw_data.get("sample_interval_s"),
        DEFAULT_SAMPLE_INTERVAL_S,
    )
    duration_source = raw_data.get("duration_minutes")
    if duration_source is None and "duration_s" in raw_data:
        duration_source = _safe_float(raw_data.get("duration_s"), 0.0)
        duration_source /= 60.0
    requested_duration = _safe_float(
        duration_source,
        DEFAULT_DURATION_MINUTES,
    )
    config.duration_minutes = (
        requested_duration
        if (
            0
            <= requested_duration
            <= MAX_SESSION_DURATION_MINUTES
        )
        else DEFAULT_DURATION_MINUTES
    )
    config.meter_rate = _enum_value_or_default(
        raw_data.get("meter_rate"),
        MeterRate,
        MeterRate.SLOW.value,
    )
    legacy_theme = str(raw_data.get("theme", "")).lower()
    requested_appearance = str(
        raw_data.get("appearance", legacy_theme)
    ).lower()
    if "light" in requested_appearance:
        requested_appearance = "light"
    elif "dark" in requested_appearance:
        requested_appearance = "dark"
    config.appearance = (
        requested_appearance
        if requested_appearance in SUPPORTED_APPEARANCES
        else DEFAULT_APPEARANCE
    )
    return config


def save_config(config: AppConfig) -> None:
    """Atomically save persistent application configuration.

    Args:
        config: Configuration values to save.

    Raises:
        OSError: If the configuration directory or file cannot be written.
    """
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_suffix(".tmp")
    payload = json.dumps(asdict(config), indent=2, sort_keys=True)
    temporary_path.write_text(payload, encoding="utf-8")
    temporary_path.replace(path)


def _validated_interval(value: object, default: float) -> float:
    """Return a validated interval from configuration data.

    Args:
        value: Untrusted configuration value.
        default: Value used when validation fails.

    Returns:
        Validated interval in seconds.
    """
    interval = _safe_float(value, default)
    if MIN_SAMPLE_INTERVAL_S <= interval <= MAX_SAMPLE_INTERVAL_S:
        return interval
    return default


def _safe_int(value: object, default: int) -> int:
    """Convert a configuration value to an integer.

    Args:
        value: Untrusted configuration value.
        default: Value returned when conversion fails.

    Returns:
        Converted integer or the supplied default.
    """
    try:
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default


def _safe_float(value: object, default: float) -> float:
    """Convert a configuration value to a float.

    Args:
        value: Untrusted configuration value.
        default: Value returned when conversion fails.

    Returns:
        Converted float or the supplied default.
    """
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default


def _enum_value_or_default(
    value: object,
    enum_type: type[ParityMode] | type[MeterRate],
    default: str,
) -> str:
    """Validate a string against a supported string enumeration.

    Args:
        value: Untrusted configuration value.
        enum_type: Enumeration used for validation.
        default: Value returned when validation fails.

    Returns:
        A supported enumeration value or the supplied default.
    """
    text = str(value)
    supported = {member.value for member in enum_type}
    return text if text in supported else default

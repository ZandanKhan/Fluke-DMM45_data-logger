"""Durable CSV session writer for Fluke 45 measurements."""

from __future__ import annotations

import csv
import logging
import re
from pathlib import Path
from typing import TextIO

from fluke45.errors import SessionError
from fluke45.models import MeterReading, SessionSettings

LOGGER = logging.getLogger(__name__)

_SAFE_NAME_PATTERN = re.compile(r"[^A-Za-z0-9._-]+")
_WINDOWS_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{index}" for index in range(1, 10)),
    *(f"LPT{index}" for index in range(1, 10)),
}
_FORMULA_PREFIXES = ("=", "+", "-", "@")
_CSV_HEADER = [
    "sample_index",
    "local_timestamp",
    "elapsed_s",
    "primary_value",
    "primary_unit",
    "secondary_value",
    "secondary_unit",
    "raw_response",
]


class CsvSessionWriter:
    """Create and write one exclusive timestamped CSV file.

    Args:
        settings: Logging session settings.
        start_stamp: Filename-safe session-start timestamp.
    """

    def __init__(
        self,
        settings: SessionSettings,
        start_stamp: str,
    ) -> None:
        """Initialize an unopened CSV session writer.

        Args:
            settings: Logging session settings.
            start_stamp: Filename-safe session-start timestamp.
        """
        self._settings = settings
        safe_name = sanitize_test_name(settings.test_name)
        file_name = f"{safe_name}_{start_stamp}_Fluke45.csv"
        self.path = settings.output_directory / file_name
        self._file: TextIO | None = None
        self._writer: csv.DictWriter[str] | None = None

    def open(self) -> None:
        """Create the output directory and new CSV file.

        Raises:
            SessionError: If the directory or file cannot be created.
        """
        try:
            self._settings.output_directory.mkdir(
                parents=True,
                exist_ok=True,
            )
            self._file = self.path.open(
                "x",
                newline="",
                encoding="utf-8-sig",
            )
            self._writer = csv.DictWriter(
                self._file,
                fieldnames=_CSV_HEADER,
                extrasaction="raise",
            )
            self._writer.writeheader()
            self._file.flush()
        except (OSError, csv.Error) as exc:
            self.close()
            raise SessionError(
                f"Could not create CSV file: {self.path}"
            ) from exc

    def write(self, reading: MeterReading) -> None:
        """Write and flush one measurement row.

        Args:
            reading: Timestamped measurement to record.

        Raises:
            SessionError: If the session is not open or writing fails.
        """
        if self._writer is None or self._file is None:
            raise SessionError("The CSV session is not open.")

        secondary_value = ""
        secondary_unit = ""
        if reading.secondary is not None:
            secondary_value = format(reading.secondary.value, ".12g")
            secondary_unit = reading.secondary.unit

        row = {
            "sample_index": str(reading.sample_index),
            "local_timestamp": reading.local_time.isoformat(
                timespec="milliseconds"
            ),
            "elapsed_s": f"{reading.elapsed_s:.3f}",
            "primary_value": format(reading.primary.value, ".12g"),
            "primary_unit": reading.primary.unit,
            "secondary_value": secondary_value,
            "secondary_unit": secondary_unit,
            "raw_response": _safe_csv_text(reading.raw_response),
        }
        try:
            self._writer.writerow(row)
            self._file.flush()
        except (OSError, csv.Error) as exc:
            raise SessionError(
                f"Could not write measurement to {self.path}."
            ) from exc

    def close(self) -> None:
        """Flush and close the CSV file if it is open."""
        file_object = self._file
        self._file = None
        self._writer = None
        if file_object is None:
            return
        try:
            file_object.flush()
            file_object.close()
        except OSError as exc:
            LOGGER.warning("Could not close CSV file %s: %s", self.path, exc)


def sanitize_test_name(test_name: str) -> str:
    """Convert a test name into a safe Windows filename component.

    Args:
        test_name: User-entered test name.

    Returns:
        A non-empty filename-safe identifier.
    """
    stripped = test_name.strip()
    normalized = _SAFE_NAME_PATTERN.sub("_", stripped)
    normalized = normalized.strip("._-")
    if not normalized:
        return "Measurement"
    normalized = normalized[:80]
    if normalized.upper() in _WINDOWS_RESERVED_NAMES:
        return f"_{normalized}"
    return normalized


def _safe_csv_text(value: str) -> str:
    """Prevent spreadsheet formula execution in a text cell.

    Args:
        value: Text that may be opened in spreadsheet software.

    Returns:
        Text prefixed with an apostrophe when formula-like.
    """
    if value.startswith(_FORMULA_PREFIXES):
        return f"'{value}"
    return value

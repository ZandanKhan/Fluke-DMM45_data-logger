"""Application-specific exception types for Fluke 45 communication."""

from __future__ import annotations


class Fluke45Error(RuntimeError):
    """Base exception for recoverable Fluke 45 application errors."""


class ProtocolError(Fluke45Error):
    """Raised when the instrument response violates the expected protocol."""


class CommandError(ProtocolError):
    """Raised when the meter returns the ``?>`` command-error prompt."""


class ExecutionError(ProtocolError):
    """Raised when the meter returns the ``!>`` execution-error prompt."""


class ResponseTimeoutError(ProtocolError):
    """Raised when a complete meter response is not received in time."""


class IdentityError(ProtocolError):
    """Raised when the connected instrument is not identified as a Fluke 45."""


class SessionError(Fluke45Error):
    """Raised when a logging session cannot be created or maintained."""

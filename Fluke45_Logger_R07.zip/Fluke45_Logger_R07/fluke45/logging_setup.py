"""Native logging configuration for the Fluke 45 application."""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from fluke45.config import get_local_app_directory

LOG_FILE_NAME = "fluke45_application.log"


def configure_logging() -> Path:
    """Configure rotating application logging.

    Returns:
        Path to the active application log file.

    Raises:
        OSError: If the log directory cannot be created.
    """
    log_directory = get_local_app_directory() / "logs"
    log_directory.mkdir(parents=True, exist_ok=True)
    log_path = log_directory / LOG_FILE_NAME

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.handlers.clear()

    handler = RotatingFileHandler(
        log_path,
        maxBytes=2_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)
    return log_path

"""Typed domain models used by the Fluke 45 logger."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Final


FLUKE45_BAUD_RATES: Final[tuple[int, ...]] = (
    300,
    600,
    1200,
    2400,
    4800,
    9600,
)
MIN_SAMPLE_INTERVAL_S: Final[float] = 0.05
MAX_SAMPLE_INTERVAL_S: Final[float] = 86_400.0
MAX_SESSION_DURATION_MINUTES: Final[float] = 525_600.0


class ParityMode(str, Enum):
    """Supported Fluke 45 serial parity selections."""

    NONE = "None"
    EVEN = "Even"
    ODD = "Odd"


class MeterRate(str, Enum):
    """Supported Fluke 45 measurement rates."""

    SLOW = "Slow"
    MEDIUM = "Medium"
    FAST = "Fast"

    @property
    def command_code(self) -> str:
        """Return the command code accepted by the meter.

        Returns:
            A one-character Fluke 45 rate code.
        """
        mapping: Final[dict[MeterRate, str]] = {
            MeterRate.SLOW: "S",
            MeterRate.MEDIUM: "M",
            MeterRate.FAST: "F",
        }
        return mapping[self]


@dataclass(frozen=True, slots=True)
class SerialSettings:
    """Serial communication settings for a Fluke 45 connection.

    Args:
        port: Windows serial port name, such as ``COM4``.
        baud_rate: Serial baud rate configured on the meter.
        parity: Serial parity configured on the meter.
        response_timeout_s: Maximum transaction response time.
        write_timeout_s: Maximum serial write time.
    """

    port: str
    baud_rate: int
    parity: ParityMode
    response_timeout_s: float = 3.0
    write_timeout_s: float = 2.0

    def __post_init__(self) -> None:
        """Validate serial settings at the domain boundary.

        Raises:
            ValueError: If a serial setting is unsupported or unsafe.
        """
        if not self.port.strip():
            raise ValueError("A serial port is required.")
        if self.baud_rate not in FLUKE45_BAUD_RATES:
            raise ValueError(
                "Unsupported Fluke 45 baud rate: "
                f"{self.baud_rate}."
            )
        if self.response_timeout_s <= 0:
            raise ValueError("Response timeout must be greater than zero.")
        if self.write_timeout_s <= 0:
            raise ValueError("Write timeout must be greater than zero.")


@dataclass(frozen=True, slots=True)
class DeviceIdentity:
    """Identification fields returned by the ``*IDN?`` query.

    Args:
        manufacturer: Instrument manufacturer.
        model: Instrument model.
        serial_number: Instrument serial number.
        firmware: Main and display firmware text.
        raw_response: Unmodified response returned by the meter.
    """

    manufacturer: str
    model: str
    serial_number: str
    firmware: str
    raw_response: str


@dataclass(frozen=True, slots=True)
class MeasurementValue:
    """One parsed display value.

    Args:
        value: Numeric value represented as a floating-point number.
        unit: Unit mnemonic returned by the meter.
        raw_text: Unmodified value segment from the meter.
    """

    value: float
    unit: str
    raw_text: str


@dataclass(frozen=True, slots=True)
class MeterReading:
    """A timestamped Fluke 45 dual-display reading.

    Args:
        sample_index: One-based CSV sample sequence number, or zero.
        local_time: Local timezone-aware computer timestamp.
        elapsed_s: Elapsed logging-session time in seconds.
        primary: Primary display value.
        secondary: Secondary display value, when active.
        raw_response: Unmodified ``VAL?`` response.
    """

    sample_index: int
    local_time: datetime
    elapsed_s: float
    primary: MeasurementValue
    secondary: MeasurementValue | None
    raw_response: str


@dataclass(frozen=True, slots=True)
class MonitorSettings:
    """Settings for continuous live-display acquisition.

    Args:
        sample_interval_s: Time between live display requests.
    """

    sample_interval_s: float

    def __post_init__(self) -> None:
        """Validate the live-display interval.

        Raises:
            ValueError: If the interval is outside supported limits.
        """
        if not (
            MIN_SAMPLE_INTERVAL_S
            <= self.sample_interval_s
            <= MAX_SAMPLE_INTERVAL_S
        ):
            raise ValueError(
                "Live interval is outside the supported range."
            )


@dataclass(frozen=True, slots=True)
class SessionSettings:
    """Settings for one CSV data-logging session.

    Args:
        output_directory: Directory used for the CSV file.
        test_name: User-entered test identifier.
        sample_interval_s: Time between requested readings.
        duration_minutes: Duration in minutes, or zero for continuous.
        meter_rate: Meter measurement-rate setting.
    """

    output_directory: Path
    test_name: str
    sample_interval_s: float
    duration_minutes: float
    meter_rate: MeterRate

    def __post_init__(self) -> None:
        """Validate logging limits at the domain boundary.

        Raises:
            ValueError: If a session setting is outside safe limits.
        """
        if not str(self.output_directory).strip():
            raise ValueError("An output directory is required.")
        if not (
            MIN_SAMPLE_INTERVAL_S
            <= self.sample_interval_s
            <= MAX_SAMPLE_INTERVAL_S
        ):
            raise ValueError(
                "Sample interval is outside the supported range."
            )
        if not (
            0
            <= self.duration_minutes
            <= MAX_SESSION_DURATION_MINUTES
        ):
            raise ValueError("Session duration is outside the safe range.")

    @property
    def duration_s(self) -> float:
        """Return the configured duration converted to seconds.

        Returns:
            Duration in seconds, or zero for continuous logging.
        """
        return self.duration_minutes * 60.0


class EventKind(str, Enum):
    """Worker-to-GUI event categories."""

    CONNECTING = "connecting"
    CONNECTED = "connected"
    CONNECTION_FAILED = "connection_failed"
    DISCONNECTED = "disconnected"
    MONITOR_STARTED = "monitor_started"
    MONITOR_STOPPED = "monitor_stopped"
    LIVE_READING = "live_reading"
    SESSION_STARTED = "session_started"
    SESSION_STOPPED = "session_stopped"
    READING = "reading"
    ERROR = "error"
    INFO = "info"


@dataclass(frozen=True, slots=True)
class WorkerEvent:
    """A message produced by the background instrument worker.

    Args:
        kind: Event category.
        message: Human-readable event description.
        payload: Optional typed payload object.
    """

    kind: EventKind
    message: str
    payload: object | None = None


class WorkerCommandKind(str, Enum):
    """Commands accepted by the background instrument worker."""

    START_MONITOR = "start_monitor"
    STOP_MONITOR = "stop_monitor"
    START_SESSION = "start_session"
    STOP_SESSION = "stop_session"
    SINGLE_READING = "single_reading"
    DISCONNECT = "disconnect"


@dataclass(frozen=True, slots=True)
class WorkerCommand:
    """A GUI-to-worker command.

    Args:
        kind: Command category.
        payload: Optional command payload.
    """

    kind: WorkerCommandKind
    payload: object | None = None

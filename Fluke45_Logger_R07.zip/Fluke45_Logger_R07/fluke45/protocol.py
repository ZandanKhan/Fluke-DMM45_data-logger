"""Fluke 45 response parsing and protocol validation helpers."""

from __future__ import annotations

import re

from fluke45.errors import IdentityError, ProtocolError
from fluke45.models import DeviceIdentity, MeasurementValue

_VALUE_PATTERN = re.compile(
    r"^\s*(?P<value>[+-]?(?:\d+(?:\.\d*)?|\.\d+)"
    r"(?:[Ee][+-]?\d+)?)\s*(?P<unit>[A-Za-z]+)?\s*$"
)


def parse_identity(response: str) -> DeviceIdentity:
    """Parse and validate a Fluke 45 identification response.

    Args:
        response: Raw response from the ``*IDN?`` query.

    Returns:
        Parsed and validated instrument identity.

    Raises:
        IdentityError: If the response is malformed or identifies another
            model.
    """
    fields = [field.strip() for field in response.split(",")]
    if len(fields) != 4:
        raise IdentityError(
            "Expected four comma-separated *IDN? fields; received "
            f"{len(fields)}."
        )

    manufacturer, model, serial_number, firmware = fields
    if manufacturer.upper() != "FLUKE" or model.strip() != "45":
        raise IdentityError(
            "Connected instrument is not a Fluke 45: "
            f"{response.strip()}"
        )
    if not serial_number:
        raise IdentityError("The Fluke 45 returned an empty serial number.")

    return DeviceIdentity(
        manufacturer=manufacturer,
        model=model,
        serial_number=serial_number,
        firmware=firmware,
        raw_response=response.strip(),
    )


def parse_measurement_value(segment: str) -> MeasurementValue:
    """Parse one numeric display segment from a Format 2 response.

    Args:
        segment: One primary or secondary display response segment.

    Returns:
        Parsed numeric value and unit.

    Raises:
        ProtocolError: If the segment cannot be parsed as a numeric value.
    """
    match = _VALUE_PATTERN.fullmatch(segment)
    if match is None:
        raise ProtocolError(
            "Could not parse measurement segment: "
            f"{segment.strip()!r}."
        )

    value_text = match.group("value")
    unit_text = match.group("unit") or ""
    try:
        numeric_value = float(value_text)
    except ValueError as exc:
        raise ProtocolError(
            f"Measurement is not numeric: {value_text!r}."
        ) from exc

    return MeasurementValue(
        value=numeric_value,
        unit=unit_text.upper(),
        raw_text=segment.strip(),
    )


def parse_measurement_response(
    response: str,
) -> tuple[MeasurementValue, MeasurementValue | None]:
    """Parse a primary or dual-display ``VAL?`` response.

    Args:
        response: Raw response returned by the meter.

    Returns:
        A primary value and an optional secondary value.

    Raises:
        ProtocolError: If the response is empty, malformed, or has too many
            values.
    """
    cleaned = response.strip()
    if not cleaned:
        raise ProtocolError(
            "The meter returned an empty measurement response."
        )

    segments = [segment.strip() for segment in cleaned.split(",")]
    if len(segments) not in (1, 2):
        raise ProtocolError(
            "Expected one or two display values; received "
            f"{len(segments)} in {cleaned!r}."
        )

    primary = parse_measurement_value(segments[0])
    secondary = None
    if len(segments) == 2:
        secondary = parse_measurement_value(segments[1])
    return primary, secondary

"""Thread-confined pySerial client for the Fluke 45 protocol."""

from __future__ import annotations

import logging
import threading
import time

import serial

from fluke45.errors import (
    CommandError,
    ExecutionError,
    ProtocolError,
    ResponseTimeoutError,
)
from fluke45.models import (
    DeviceIdentity,
    MeasurementValue,
    MeterRate,
    ParityMode,
    SerialSettings,
)
from fluke45.protocol import parse_identity, parse_measurement_response

LOGGER = logging.getLogger(__name__)
_SUCCESS_PROMPT = "=>"
_COMMAND_ERROR_PROMPT = "?>"
_EXECUTION_ERROR_PROMPT = "!>"
_PROMPTS = {
    _SUCCESS_PROMPT,
    _COMMAND_ERROR_PROMPT,
    _EXECUTION_ERROR_PROMPT,
}


class Fluke45SerialClient:
    """Manage one prompt-synchronized Fluke 45 serial connection.

    Args:
        settings: Serial connection settings.
    """

    def __init__(self, settings: SerialSettings) -> None:
        """Initialize an unopened Fluke 45 serial client.

        Args:
            settings: Serial connection settings.
        """
        self._settings = settings
        self._serial: serial.Serial | None = None
        self._transaction_lock = threading.Lock()

    @property
    def is_open(self) -> bool:
        """Return whether the serial port is open.

        Returns:
            ``True`` when an active serial connection exists.
        """
        return self._serial is not None and self._serial.is_open

    def open(self) -> DeviceIdentity:
        """Open, synchronize, and identify the connected instrument.

        Returns:
            Validated Fluke 45 identity information.

        Raises:
            serial.SerialException: If the serial port cannot be opened.
            ProtocolError: If communication or identification fails.
        """
        if self.is_open:
            raise ProtocolError("The serial connection is already open.")

        bytesize, parity = self._serial_framing(self._settings.parity)
        stream = serial.Serial(
            port=self._settings.port,
            baudrate=self._settings.baud_rate,
            bytesize=bytesize,
            parity=parity,
            stopbits=serial.STOPBITS_ONE,
            timeout=0.10,
            write_timeout=self._settings.write_timeout_s,
            xonxoff=False,
            rtscts=False,
            dsrdtr=False,
        )
        self._serial = stream
        try:
            stream.reset_input_buffer()
            stream.reset_output_buffer()
            self._synchronize_prompt()
            identity_text = self.query("*IDN?")
            identity = parse_identity(identity_text)
            self.command("FORMAT 2")
        except (
            CommandError,
            ExecutionError,
            ProtocolError,
            ResponseTimeoutError,
            serial.SerialException,
            serial.SerialTimeoutException,
        ):
            self.close()
            raise

        LOGGER.info(
            "Connected to %s on %s at %d baud.",
            identity.raw_response,
            self._settings.port,
            self._settings.baud_rate,
        )
        return identity

    def close(self) -> None:
        """Close the serial connection and release the COM port."""
        stream = self._serial
        self._serial = None
        if stream is None:
            return
        try:
            if stream.is_open:
                stream.close()
        except serial.SerialException as exc:
            LOGGER.warning("Serial close failed: %s", exc)

    def set_measurement_rate(self, rate: MeterRate) -> None:
        """Set the Fluke 45 internal reading rate.

        Args:
            rate: Requested slow, medium, or fast rate.

        Raises:
            ProtocolError: If the meter rejects the command.
        """
        self.command(f"RATE {rate.command_code}")

    def read_display(
        self,
    ) -> tuple[
        str,
        MeasurementValue,
        MeasurementValue | None,
    ]:
        """Read and parse the currently displayed value or values.

        Returns:
            Raw response, primary value, and optional secondary value.

        Raises:
            ProtocolError: If the response cannot be read or parsed.
        """
        response = self.query("VAL?")
        primary, secondary = parse_measurement_response(response)
        return response, primary, secondary

    def command(self, command_text: str) -> None:
        """Send a non-query command and validate the success prompt.

        Args:
            command_text: Fluke 45 command without a terminator.

        Raises:
            ProtocolError: If the command fails or returns unexpected data.
        """
        response_lines = self._transact(command_text)
        if response_lines:
            LOGGER.debug(
                "Command %s returned unexpected data: %s",
                command_text,
                response_lines,
            )

    def query(self, command_text: str) -> str:
        """Send a query and return its response text.

        Args:
            command_text: Fluke 45 query without a terminator.

        Returns:
            Query response lines joined with a newline.

        Raises:
            ProtocolError: If no response data is returned.
        """
        response_lines = self._transact(command_text)
        if not response_lines:
            raise ProtocolError(
                f"The meter returned no data for query {command_text!r}."
            )
        return "\n".join(response_lines)

    def _transact(self, command_text: str) -> list[str]:
        """Perform one complete command-response-prompt transaction.

        Args:
            command_text: Fluke 45 command without a terminator.

        Returns:
            Response data lines, excluding command echo and prompt.

        Raises:
            CommandError: If the meter reports a syntax error.
            ExecutionError: If the meter reports an execution error.
            ResponseTimeoutError: If no complete response is received.
            serial.SerialException: If the serial link fails.
        """
        stream = self._require_open_stream()
        normalized_command = command_text.strip()
        if not normalized_command:
            raise ProtocolError("A blank command cannot be sent.")
        try:
            encoded_command = normalized_command.encode("ascii")
        except UnicodeEncodeError as exc:
            raise ProtocolError(
                "Fluke 45 commands must contain ASCII characters only."
            ) from exc
        if len(encoded_command) > 340:
            raise ProtocolError("Command exceeds the safe input-buffer limit.")

        with self._transaction_lock:
            payload = encoded_command + b"\r"
            stream.write(payload)
            stream.flush()
            lines, prompt = self._read_until_prompt(
                self._settings.response_timeout_s
            )

        filtered = [
            line
            for line in lines
            if line.strip().upper() != normalized_command.upper()
        ]
        if prompt == _COMMAND_ERROR_PROMPT:
            raise CommandError(
                f"The meter rejected command {normalized_command!r}."
            )
        if prompt == _EXECUTION_ERROR_PROMPT:
            raise ExecutionError(
                "The meter understood but could not execute command "
                f"{normalized_command!r}."
            )
        return filtered

    def _synchronize_prompt(self) -> None:
        """Clear pending input and obtain a fresh meter prompt.

        Raises:
            ResponseTimeoutError: If the meter does not return a prompt.
            serial.SerialException: If the serial link fails.
        """
        stream = self._require_open_stream()
        stream.write(b"\x03")
        stream.flush()
        try:
            self._read_until_prompt(self._settings.response_timeout_s)
        except ResponseTimeoutError:
            stream.reset_input_buffer()
            LOGGER.info(
                "No prompt followed device clear; trying direct query."
            )

    def _read_until_prompt(
        self,
        timeout_s: float,
    ) -> tuple[list[str], str]:
        """Read ASCII lines until a recognized meter prompt arrives.

        Args:
            timeout_s: Maximum time to wait for a complete transaction.

        Returns:
            Response lines and the final meter prompt.

        Raises:
            ProtocolError: If non-ASCII data or excessive data is received.
            ResponseTimeoutError: If the prompt is not received in time.
            serial.SerialException: If the serial link fails.
        """
        stream = self._require_open_stream()
        deadline = time.monotonic() + timeout_s
        response_lines: list[str] = []
        received_bytes = 0

        while time.monotonic() < deadline:
            raw_line = stream.readline()
            if not raw_line:
                continue
            received_bytes += len(raw_line)
            if received_bytes > 8_192:
                raise ProtocolError(
                    "Meter response exceeded the 8192-byte safety limit."
                )
            try:
                line = raw_line.decode("ascii").strip("\r\n")
            except UnicodeDecodeError as exc:
                raise ProtocolError(
                    "Meter returned non-ASCII serial data."
                ) from exc

            stripped = line.strip()
            if not stripped:
                continue
            if stripped in _PROMPTS:
                return response_lines, stripped
            response_lines.append(stripped)

        raise ResponseTimeoutError(
            "Timed out waiting for the Fluke 45 response prompt."
        )

    def _require_open_stream(self) -> serial.Serial:
        """Return the open serial object.

        Returns:
            Active pySerial stream.

        Raises:
            ProtocolError: If the client is not connected.
        """
        if self._serial is None or not self._serial.is_open:
            raise ProtocolError("The Fluke 45 serial port is not open.")
        return self._serial

    @staticmethod
    def _serial_framing(parity_mode: ParityMode) -> tuple[int, str]:
        """Map a meter parity setting to pySerial framing.

        Args:
            parity_mode: User-selected meter parity.

        Returns:
            pySerial data-bit and parity constants.
        """
        if parity_mode is ParityMode.EVEN:
            return serial.SEVENBITS, serial.PARITY_EVEN
        if parity_mode is ParityMode.ODD:
            return serial.SEVENBITS, serial.PARITY_ODD
        return serial.EIGHTBITS, serial.PARITY_NONE

"""Locate and configure the Tcl/Tk runtime used by Tkinter on Windows."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


class TkRuntimeError(RuntimeError):
    """Raised when the Tcl/Tk script libraries cannot be located."""


@dataclass(frozen=True, slots=True)
class TkRuntimePaths:
    """Resolved Tcl and Tk script-library directories.

    Args:
        tcl_library: Directory containing ``init.tcl``.
        tk_library: Directory containing ``tk.tcl``.
    """

    tcl_library: Path
    tk_library: Path


def _unique_paths(paths: Iterable[Path]) -> list[Path]:
    """Return normalized paths without duplicates.

    Args:
        paths: Candidate paths in preferred search order.

    Returns:
        Existing and non-existing unique paths in the same order.
    """
    unique: list[Path] = []
    seen: set[str] = set()
    for path in paths:
        normalized = path.expanduser().resolve(strict=False)
        key = os.path.normcase(str(normalized))
        if key not in seen:
            seen.add(key)
            unique.append(normalized)
    return unique


def _default_search_roots() -> list[Path]:
    """Build the Tcl/Tk search-root list for the active interpreter.

    Returns:
        Candidate Python installation roots.
    """
    roots = [
        Path(sys.base_prefix),
        Path(sys.base_exec_prefix),
        Path(sys.executable).resolve().parent,
        Path(sys.prefix),
        Path(sys.exec_prefix),
    ]
    return _unique_paths(roots)


def _valid_library_from_environment(
    variable_name: str,
    marker_file: str,
) -> Path | None:
    """Return a valid library directory from an environment variable.

    Args:
        variable_name: Environment-variable name to inspect.
        marker_file: Required file proving that the directory is valid.

    Returns:
        Validated directory, or ``None`` when unavailable.
    """
    raw_value = os.environ.get(variable_name, "").strip()
    if not raw_value:
        return None
    candidate = Path(raw_value).expanduser().resolve(strict=False)
    if (candidate / marker_file).is_file():
        return candidate
    return None


def _find_library(
    roots: Iterable[Path],
    family_prefix: str,
    marker_file: str,
) -> Path | None:
    """Find a Tcl or Tk library directory beneath Python roots.

    Args:
        roots: Candidate Python installation roots.
        family_prefix: Directory prefix, such as ``tcl`` or ``tk``.
        marker_file: Required library file.

    Returns:
        Matching directory, or ``None`` when no match exists.
    """
    for root in _unique_paths(roots):
        tcl_root = root / "tcl"
        direct_candidates = [
            tcl_root / f"{family_prefix}8.6",
            tcl_root / f"{family_prefix}8.7",
            root / "lib" / f"{family_prefix}8.6",
            root / "lib" / f"{family_prefix}8.7",
        ]
        for candidate in direct_candidates:
            if (candidate / marker_file).is_file():
                return candidate

        if not tcl_root.is_dir():
            continue
        for candidate in sorted(tcl_root.glob(f"{family_prefix}*")):
            if candidate.is_dir() and (candidate / marker_file).is_file():
                return candidate
    return None


def discover_tk_runtime(
    search_roots: Iterable[Path] | None = None,
) -> TkRuntimePaths:
    """Discover usable Tcl and Tk script-library directories.

    Args:
        search_roots: Optional installation roots used by tests or tools.

    Returns:
        Validated Tcl and Tk library paths.

    Raises:
        TkRuntimeError: If either required library cannot be located.
    """
    roots = (
        _default_search_roots()
        if search_roots is None
        else _unique_paths(search_roots)
    )
    tcl_library = _find_library(roots, "tcl", "init.tcl")
    tk_library = _find_library(roots, "tk", "tk.tcl")

    if tcl_library is None:
        tcl_library = _valid_library_from_environment(
            "TCL_LIBRARY",
            "init.tcl",
        )
    if tk_library is None:
        tk_library = _valid_library_from_environment(
            "TK_LIBRARY",
            "tk.tcl",
        )

    if tcl_library is None or tk_library is None:
        roots_text = ", ".join(str(path) for path in roots)
        raise TkRuntimeError(
            "Python Tcl/Tk support is incomplete. The application could "
            "not locate init.tcl and tk.tcl. Python search roots: "
            f"{roots_text}"
        )

    return TkRuntimePaths(
        tcl_library=tcl_library,
        tk_library=tk_library,
    )


def configure_tk_runtime(
    search_roots: Iterable[Path] | None = None,
) -> TkRuntimePaths:
    """Set process-local Tcl/Tk library variables when necessary.

    Args:
        search_roots: Optional installation roots used by tests or tools.

    Returns:
        Configured Tcl and Tk library paths.

    Raises:
        TkRuntimeError: If the required Tcl/Tk files are unavailable.
    """
    runtime = discover_tk_runtime(search_roots)
    os.environ["TCL_LIBRARY"] = str(runtime.tcl_library)
    os.environ["TK_LIBRARY"] = str(runtime.tk_library)
    return runtime

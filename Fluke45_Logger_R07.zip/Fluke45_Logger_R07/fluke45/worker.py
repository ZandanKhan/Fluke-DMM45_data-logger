"""Background worker that owns the serial port and acquisition modes."""

from __future__ import annotations

import logging
import queue
import threading
import time
from datetime import datetime

import serial

from fluke45.csv_session import CsvSessionWriter
from fluke45.errors import Fluke45Error, ProtocolError, SessionError
from fluke45.models import (
    EventKind,
    MeterReading,
    MonitorSettings,
    SerialSettings,
    SessionSettings,
    WorkerCommand,
    WorkerCommandKind,
    WorkerEvent,
)
from fluke45.serial_client import Fluke45SerialClient

LOGGER = logging.getLogger(__name__)
_MAX_CONSECUTIVE_ERRORS = 5


class InstrumentWorker(threading.Thread):
    """Own one Fluke 45 connection and process GUI commands safely.

    Args:
        settings: Serial connection settings.
        event_queue: Queue used to publish worker events.
    """

    def __init__(
        self,
        settings: SerialSettings,
        event_queue: queue.Queue[WorkerEvent],
    ) -> None:
        """Initialize the background worker.

        Args:
            settings: Serial connection settings.
            event_queue: Queue used to publish worker events.
        """
        super().__init__(name="Fluke45Worker", daemon=True)
        self._settings = settings
        self._event_queue = event_queue
        self._command_queue: queue.Queue[WorkerCommand] = queue.Queue()
        self._shutdown_event = threading.Event()
        self._client = Fluke45SerialClient(settings)
        self._session_writer: CsvSessionWriter | None = None
        self._session_settings: SessionSettings | None = None
        self._session_start_monotonic = 0.0
        self._next_session_sample_monotonic = 0.0
        self._sample_index = 0
        self._monitor_settings: MonitorSettings | None = None
        self._next_monitor_sample_monotonic = 0.0
        self._consecutive_errors = 0

    def submit(self, command: WorkerCommand) -> None:
        """Submit a command to the instrument thread.

        Args:
            command: Worker command to enqueue.
        """
        self._command_queue.put(command)

    def run(self) -> None:
        """Connect to the meter and service commands until shutdown."""
        self._emit(EventKind.CONNECTING, "Opening the serial connection...")
        try:
            identity = self._client.open()
        except (
            serial.SerialException,
            serial.SerialTimeoutException,
            Fluke45Error,
        ) as exc:
            LOGGER.error("Connection failed: %s", exc)
            self._emit(EventKind.CONNECTION_FAILED, str(exc))
            self._client.close()
            return

        self._emit(
            EventKind.CONNECTED,
            f"Connected to {identity.manufacturer} {identity.model}.",
            identity,
        )

        try:
            self._service_loop()
        finally:
            self._stop_monitor("Live display stopped.")
            self._stop_session("Connection closed")
            self._client.close()
            self._emit(EventKind.DISCONNECTED, "Serial port released.")

    def _service_loop(self) -> None:
        """Process commands and scheduled readings until disconnected."""
        while not self._shutdown_event.is_set():
            timeout_s = self._calculate_command_wait()
            try:
                command = self._command_queue.get(timeout=timeout_s)
            except queue.Empty:
                command = None

            if command is not None:
                self._handle_command(command)

            if self._session_writer is not None:
                self._run_scheduled_session_sample()
                self._check_duration_limit()
            elif self._monitor_settings is not None:
                self._run_scheduled_monitor_sample()

    def _calculate_command_wait(self) -> float:
        """Calculate a responsive queue wait time.

        Returns:
            Time in seconds before the next scheduled action.
        """
        next_due: float | None = None
        if self._session_writer is not None:
            next_due = self._next_session_sample_monotonic
        elif self._monitor_settings is not None:
            next_due = self._next_monitor_sample_monotonic
        if next_due is None:
            return 0.20
        remaining = next_due - time.monotonic()
        return max(0.0, min(0.10, remaining))

    def _handle_command(self, command: WorkerCommand) -> None:
        """Execute one GUI command on the worker thread.

        Args:
            command: Command to process.
        """
        if command.kind is WorkerCommandKind.DISCONNECT:
            self._shutdown_event.set()
            return
        if command.kind is WorkerCommandKind.STOP_MONITOR:
            self._stop_monitor("Live display stopped by user.")
            return
        if command.kind is WorkerCommandKind.STOP_SESSION:
            self._stop_session("Stopped by user")
            return
        if command.kind is WorkerCommandKind.SINGLE_READING:
            self._take_single_reading()
            return
        if command.kind is WorkerCommandKind.START_MONITOR:
            if not isinstance(command.payload, MonitorSettings):
                self._emit(
                    EventKind.ERROR,
                    "Invalid live-display command payload.",
                )
                return
            self._start_monitor(command.payload)
            return
        if command.kind is WorkerCommandKind.START_SESSION:
            if not isinstance(command.payload, SessionSettings):
                self._emit(
                    EventKind.ERROR,
                    "Invalid logging-session command payload.",
                )
                return
            self._start_session(command.payload)

    def _start_monitor(self, settings: MonitorSettings) -> None:
        """Start continuous live-display acquisition.

        Args:
            settings: Requested live-display settings.
        """
        if self._session_writer is not None:
            self._emit(
                EventKind.ERROR,
                "Stop CSV logging before starting live display mode.",
            )
            return
        if self._monitor_settings is not None:
            self._emit(
                EventKind.ERROR,
                "Live display mode is already active.",
            )
            return
        try:
            self._client.command("FORMAT 2")
        except serial.SerialException as exc:
            self._emit(EventKind.ERROR, str(exc))
            self._shutdown_event.set()
            return
        except Fluke45Error as exc:
            self._emit(EventKind.ERROR, str(exc))
            return

        self._monitor_settings = settings
        self._next_monitor_sample_monotonic = time.monotonic()
        self._consecutive_errors = 0
        self._emit(
            EventKind.MONITOR_STARTED,
            (
                "Live display started at "
                f"{settings.sample_interval_s:g} second interval."
            ),
        )

    def _stop_monitor(self, reason: str) -> None:
        """Stop continuous live-display acquisition.

        Args:
            reason: Human-readable stop reason.
        """
        if self._monitor_settings is None:
            return
        self._monitor_settings = None
        self._emit(EventKind.MONITOR_STOPPED, reason)

    def _start_session(self, settings: SessionSettings) -> None:
        """Validate settings and open a new CSV logging session.

        Args:
            settings: Requested session settings.
        """
        if self._session_writer is not None:
            self._emit(
                EventKind.ERROR,
                "A logging session is already active.",
            )
            return
        if self._monitor_settings is not None:
            self._emit(
                EventKind.ERROR,
                "Stop live display mode before starting CSV logging.",
            )
            return

        start_local = datetime.now().astimezone()
        start_stamp = start_local.strftime("%Y%m%d_%H%M%S_%f")
        writer = CsvSessionWriter(settings, start_stamp)
        try:
            self._client.command("FORMAT 2")
            self._client.set_measurement_rate(settings.meter_rate)
            writer.open()
        except serial.SerialException as exc:
            writer.close()
            self._emit(EventKind.ERROR, str(exc))
            self._shutdown_event.set()
            return
        except Fluke45Error as exc:
            writer.close()
            self._emit(EventKind.ERROR, str(exc))
            return

        self._session_writer = writer
        self._session_settings = settings
        self._session_start_monotonic = time.monotonic()
        self._next_session_sample_monotonic = (
            self._session_start_monotonic
        )
        self._sample_index = 0
        self._consecutive_errors = 0
        LOGGER.info("CSV session started: %s", writer.path)
        self._emit(
            EventKind.SESSION_STARTED,
            f"Logging started: {writer.path.name}",
            writer.path,
        )

    def _stop_session(self, reason: str) -> None:
        """Close an active CSV session and publish its final path.

        Args:
            reason: Human-readable stop reason.
        """
        writer = self._session_writer
        self._session_writer = None
        self._session_settings = None
        if writer is None:
            return
        writer.close()
        LOGGER.info("CSV session stopped: %s", reason)
        self._emit(
            EventKind.SESSION_STOPPED,
            reason,
            writer.path,
        )

    def _take_single_reading(self) -> None:
        """Acquire one display reading without writing a CSV row."""
        try:
            reading = self._acquire_reading(0, 0.0)
        except serial.SerialException as exc:
            self._emit(EventKind.ERROR, str(exc))
            self._shutdown_event.set()
            return
        except ProtocolError as exc:
            self._emit(EventKind.ERROR, str(exc))
            return
        self._emit(EventKind.READING, "Single reading acquired.", reading)

    def _run_scheduled_monitor_sample(self) -> None:
        """Acquire a live display sample when its interval expires."""
        settings = self._monitor_settings
        if settings is None:
            return
        now_monotonic = time.monotonic()
        if now_monotonic < self._next_monitor_sample_monotonic:
            return

        try:
            reading = self._acquire_reading(0, 0.0)
        except serial.SerialException as exc:
            LOGGER.error("Serial connection failed: %s", exc)
            self._emit(EventKind.ERROR, str(exc))
            self._stop_monitor("Live display stopped: serial link failed.")
            self._shutdown_event.set()
        except ProtocolError as exc:
            self._consecutive_errors += 1
            LOGGER.warning("Live display acquisition failed: %s", exc)
            self._emit(EventKind.ERROR, str(exc))
            if self._consecutive_errors >= _MAX_CONSECUTIVE_ERRORS:
                self._stop_monitor(
                    "Live display stopped after five acquisition errors."
                )
        else:
            self._consecutive_errors = 0
            self._emit(
                EventKind.LIVE_READING,
                "Live display updated.",
                reading,
            )

        completed = time.monotonic()
        next_due = (
            self._next_monitor_sample_monotonic
            + settings.sample_interval_s
        )
        if next_due <= completed:
            next_due = completed + settings.sample_interval_s
        self._next_monitor_sample_monotonic = next_due

    def _run_scheduled_session_sample(self) -> None:
        """Acquire and record a sample when its scheduled time arrives."""
        settings = self._session_settings
        writer = self._session_writer
        if settings is None or writer is None:
            return

        now_monotonic = time.monotonic()
        if now_monotonic < self._next_session_sample_monotonic:
            return

        sample_monotonic = time.monotonic()
        elapsed_s = sample_monotonic - self._session_start_monotonic
        try:
            self._sample_index += 1
            reading = self._acquire_reading(
                self._sample_index,
                elapsed_s,
            )
            writer.write(reading)
        except SessionError as exc:
            LOGGER.error("CSV write failed: %s", exc)
            self._emit(EventKind.ERROR, str(exc))
            self._stop_session("Stopped because the CSV write failed.")
        except serial.SerialException as exc:
            LOGGER.error("Serial connection failed: %s", exc)
            self._emit(EventKind.ERROR, str(exc))
            self._stop_session("Stopped because the serial link failed.")
            self._shutdown_event.set()
        except ProtocolError as exc:
            self._sample_index -= 1
            self._consecutive_errors += 1
            LOGGER.warning("Measurement failed: %s", exc)
            self._emit(EventKind.ERROR, str(exc))
            if self._consecutive_errors >= _MAX_CONSECUTIVE_ERRORS:
                self._stop_session(
                    "Stopped after five consecutive acquisition errors."
                )
        else:
            self._consecutive_errors = 0
            self._emit(EventKind.READING, "Measurement recorded.", reading)

        completed = time.monotonic()
        next_due = (
            self._next_session_sample_monotonic
            + settings.sample_interval_s
        )
        if next_due <= completed:
            next_due = completed + settings.sample_interval_s
        self._next_session_sample_monotonic = next_due

    def _acquire_reading(
        self,
        sample_index: int,
        elapsed_s: float,
    ) -> MeterReading:
        """Read and package one meter response.

        Args:
            sample_index: CSV sample sequence number, or zero.
            elapsed_s: Elapsed logging time in seconds.

        Returns:
            Parsed and locally timestamped meter reading.

        Raises:
            serial.SerialException: If serial communication fails.
            ProtocolError: If the meter response cannot be parsed.
        """
        raw_response, primary, secondary = self._client.read_display()
        return MeterReading(
            sample_index=sample_index,
            local_time=datetime.now().astimezone(),
            elapsed_s=elapsed_s,
            primary=primary,
            secondary=secondary,
            raw_response=raw_response,
        )

    def _check_duration_limit(self) -> None:
        """Stop the session when the requested duration has elapsed."""
        settings = self._session_settings
        if settings is None or settings.duration_s <= 0:
            return
        elapsed_s = time.monotonic() - self._session_start_monotonic
        if elapsed_s >= settings.duration_s:
            self._stop_session("Requested duration completed.")

    def _emit(
        self,
        kind: EventKind,
        message: str,
        payload: object | None = None,
    ) -> None:
        """Publish a worker event to the GUI.

        Args:
            kind: Event category.
            message: Human-readable description.
            payload: Optional event payload.
        """
        self._event_queue.put(
            WorkerEvent(kind=kind, message=message, payload=payload)
        )

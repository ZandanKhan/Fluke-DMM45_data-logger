"""Executable entry point for the Fluke 45 desktop logger."""

from __future__ import annotations

import logging
import tkinter as tk
from tkinter import messagebox

from fluke45.logging_setup import configure_logging
from fluke45.tk_runtime import TkRuntimeError, configure_tk_runtime

LOGGER = logging.getLogger(__name__)


def _show_startup_error(message: str) -> None:
    """Display a startup failure before the main GUI is available.

    Args:
        message: Human-readable startup failure description.
    """
    try:
        configure_tk_runtime()
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "Fluke 45 Logger Startup Error",
            message,
            parent=root,
        )
        root.destroy()
    except (tk.TclError, TkRuntimeError):
        LOGGER.critical(message)


def main() -> int:
    """Configure logging and launch the application.

    Returns:
        Process exit status code.
    """
    try:
        configure_logging()
    except OSError:
        logging.basicConfig(level=logging.INFO)
        LOGGER.warning("File logging could not be initialized.")

    try:
        runtime = configure_tk_runtime()
    except TkRuntimeError as exc:
        LOGGER.critical("Tcl/Tk runtime is unavailable: %s", exc)
        LOGGER.critical(
            "Modify or repair Python 3.13 and install Tcl/Tk and IDLE."
        )
        return 4

    LOGGER.info("Tcl library: %s", runtime.tcl_library)
    LOGGER.info("Tk library: %s", runtime.tk_library)

    try:
        from fluke45.app import run_application
    except ImportError as exc:
        LOGGER.critical(
            "A required Python package could not be imported.",
            exc_info=exc,
        )
        _show_startup_error(
            "A required Python package is missing. Run "
            "install_fluke45.bat, then start the application again."
        )
        return 3

    return run_application()


if __name__ == "__main__":
    raise SystemExit(main())

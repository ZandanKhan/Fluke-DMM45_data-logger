@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHONUTF8=1"

echo ============================================================
echo Fluke 45 Logger R07 - Standard Tkinter Installation
echo ============================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo Python Launcher was not found.
    echo Install Python 3.13 with the Python Launcher enabled.
    pause
    exit /b 1
)

py -3.13 --version
if errorlevel 1 goto :python_failed

echo.
echo Checking the base Python Tcl/Tk installation...
py -3.13 -c "from fluke45.tk_runtime import configure_tk_runtime; r=configure_tk_runtime(); print('Tcl library:', r.tcl_library); print('Tk library:', r.tk_library)"
if errorlevel 1 goto :tk_failed

py -3.13 -c "from fluke45.tk_runtime import configure_tk_runtime; configure_tk_runtime(); import tkinter as tk; root=tk.Tk(); root.withdraw(); print('Tk runtime:', root.tk.call('info', 'patchlevel')); root.destroy()"
if errorlevel 1 goto :tk_failed

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo Creating the private Python environment...
    py -3.13 -m venv .venv
    if errorlevel 1 goto :failed
)

call ".venv\Scripts\activate.bat"
if errorlevel 1 goto :failed

echo.
echo Updating pip...
python -m pip install --upgrade pip
if errorlevel 1 goto :failed

echo Installing pySerial...
python -m pip install --upgrade -r requirements.txt
if errorlevel 1 goto :failed

echo Verifying Tkinter, pySerial, and application imports...
python -c "from fluke45.tk_runtime import configure_tk_runtime; configure_tk_runtime(); import tkinter; import tkinter.ttk; import serial; import fluke45.app"
if errorlevel 1 goto :failed

echo Running the hidden GUI construction test...
python -c "from fluke45.app import smoke_test_application; raise SystemExit(smoke_test_application())"
if errorlevel 1 goto :failed

echo Running automated tests...
python -m unittest discover -s tests -v
if errorlevel 1 goto :failed

echo.
python -c "import sys, serial; from fluke45.tk_runtime import configure_tk_runtime; r=configure_tk_runtime(); print(sys.version); print('pyserial', serial.VERSION); print('Tcl', r.tcl_library); print('Tk', r.tk_library)"
if errorlevel 1 goto :failed

echo.
echo Installation and self-tests completed successfully.
echo Start the application using run_fluke45.bat.
pause
exit /b 0

:tk_failed
echo.
echo ============================================================
echo PYTHON TCL/TK COMPONENT IS MISSING OR DAMAGED
echo ============================================================
echo.
echo The Fluke application requires Python standard Tkinter.
echo Your Python 3.13 installation cannot create a Tk window.
echo.
echo Corrective procedure:
echo   1. Open Windows Settings.
echo   2. Select Apps, then Installed apps.
echo   3. Find Python 3.13 ^(64-bit^).
echo   4. Select Modify.
echo   5. Enable "tcl/tk and IDLE".
echo   6. Complete Modify. If already enabled, select Repair.
echo   7. Run: py -3.13 -m tkinter
echo   8. A small Tk demonstration window must open.
echo   9. Delete this folder's .venv directory.
echo  10. Run install_fluke45.bat again.
echo.
echo The application cannot supply missing Python Tcl/Tk system files.
pause
exit /b 4

:python_failed
echo.
echo Python 3.13 could not be started through the py launcher.
pause
exit /b 3

:failed
echo.
echo Installation failed. Review the detailed message above.
pause
exit /b 1

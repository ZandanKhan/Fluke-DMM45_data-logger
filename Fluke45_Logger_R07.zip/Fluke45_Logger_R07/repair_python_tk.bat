@echo off
setlocal EnableExtensions

echo ============================================================
echo Python 3.13 Tcl/Tk Repair Guide
echo ============================================================
echo.
echo 1. In Installed Apps, find Python 3.13 ^(64-bit^).
echo 2. Select Modify.
echo 3. Enable "tcl/tk and IDLE".
echo 4. Complete Modify.
echo 5. If it was already enabled, run Repair.
echo 6. Test with: py -3.13 -m tkinter
echo 7. Delete the Fluke R07 .venv folder.
echo 8. Run install_fluke45.bat again.
echo.
echo Opening Windows Installed Apps...
start "" ms-settings:appsfeatures
pause

@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHONUTF8=1"
set "PYTHON_EXE=.venv\Scripts\python.exe"
set "LAUNCH_LOG=%~dp0launcher_error.log"
set "APP_LOG=%LOCALAPPDATA%\Fluke45Logger\logs\fluke45_application.log"

if not exist "%PYTHON_EXE%" (
    echo The private Python environment is missing.
    echo Run install_fluke45.bat first.
    pause
    exit /b 1
)

"%PYTHON_EXE%" -c "from fluke45.tk_runtime import configure_tk_runtime; configure_tk_runtime(); import tkinter; import serial; import fluke45.app"
if errorlevel 1 (
    echo.
    echo Python Tcl/Tk or an application dependency could not be loaded.
    echo Run install_fluke45.bat and follow the displayed repair steps.
    pause
    exit /b 2
)

if exist "%LAUNCH_LOG%" del /q "%LAUNCH_LOG%" >nul 2>nul

"%PYTHON_EXE%" -X faulthandler fluke45_logger.py 2>"%LAUNCH_LOG%"
set "APP_EXIT_CODE=%ERRORLEVEL%"

if not "%APP_EXIT_CODE%"=="0" (
    echo.
    echo The application ended with error code %APP_EXIT_CODE%.
    echo.

    if exist "%LAUNCH_LOG%" (
        for %%A in ("%LAUNCH_LOG%") do if %%~zA GTR 0 (
            echo Python error details:
            echo ------------------------------------------------------------
            type "%LAUNCH_LOG%"
            echo ------------------------------------------------------------
        )
    )

    if exist "%APP_LOG%" (
        echo.
        echo Recent application log entries:
        echo ------------------------------------------------------------
        powershell -NoProfile -ExecutionPolicy Bypass -Command ^
            "Get-Content -LiteralPath '%APP_LOG%' -Tail 30"
        echo ------------------------------------------------------------
    )

    echo.
    echo Diagnostic files:
    echo   %LAUNCH_LOG%
    echo   %APP_LOG%
    pause
    exit /b %APP_EXIT_CODE%
)

exit /b 0

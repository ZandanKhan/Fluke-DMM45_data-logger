"""Unit tests for durable Fluke 45 CSV session output."""

from __future__ import annotations

import csv
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from fluke45.csv_session import CsvSessionWriter, sanitize_test_name
from fluke45.models import (
    MeasurementValue,
    MeterRate,
    MeterReading,
    SessionSettings,
)


class CsvSessionTests(unittest.TestCase):
    """Verify filename sanitization and CSV row writing."""

    def test_sanitize_test_name(self) -> None:
        """Remove path separators and unsafe filename characters."""
        self.assertEqual(
            sanitize_test_name("  Lab/Test:01  "),
            "Lab_Test_01",
        )

    def test_reserved_windows_name(self) -> None:
        """Prefix a reserved Windows device filename."""
        self.assertEqual(sanitize_test_name("CON"), "_CON")

    def test_write_dual_display_row(self) -> None:
        """Create one CSV row with local computer time only."""
        with tempfile.TemporaryDirectory() as temporary_directory:
            settings = SessionSettings(
                output_directory=Path(temporary_directory),
                test_name="Bench Test",
                sample_interval_s=1.0,
                duration_minutes=10.0,
                meter_rate=MeterRate.SLOW,
            )
            writer = CsvSessionWriter(settings, "20260730_173000")
            writer.open()
            timestamp = datetime(
                2026,
                7,
                30,
                17,
                30,
                tzinfo=timezone.utc,
            )
            reading = MeterReading(
                sample_index=1,
                local_time=timestamp,
                elapsed_s=0.0,
                primary=MeasurementValue(12.0, "VDC", "12 VDC"),
                secondary=MeasurementValue(60.0, "HZ", "60 HZ"),
                raw_response="+1.2000E+1 VDC, +6.0000E+1 HZ",
            )
            writer.write(reading)
            writer.close()

            with writer.path.open(
                newline="",
                encoding="utf-8-sig",
            ) as csv_file:
                rows = list(csv.DictReader(csv_file))
            self.assertEqual(len(rows), 1)
            self.assertIn("local_timestamp", rows[0])
            self.assertNotIn("utc_timestamp", rows[0])
            self.assertEqual(rows[0]["primary_value"], "12")
            self.assertEqual(rows[0]["secondary_value"], "60")
            self.assertEqual(rows[0]["primary_unit"], "VDC")
            self.assertEqual(rows[0]["secondary_unit"], "HZ")
            self.assertTrue(rows[0]["raw_response"].startswith("'"))


if __name__ == "__main__":
    unittest.main()

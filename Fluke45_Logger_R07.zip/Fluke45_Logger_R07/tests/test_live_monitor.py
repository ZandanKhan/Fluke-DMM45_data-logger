"""Tests for live monitoring and minute-based session settings."""

from __future__ import annotations

import unittest
from pathlib import Path

from fluke45.models import (
    MeterRate,
    MonitorSettings,
    SessionSettings,
)


class LiveMonitorTests(unittest.TestCase):
    """Verify new R07 acquisition settings and conversions."""

    def test_monitor_interval_is_validated(self) -> None:
        """Reject live-display intervals below the supported limit."""
        with self.assertRaises(ValueError):
            MonitorSettings(sample_interval_s=0.01)

    def test_monitor_interval_accepts_one_second(self) -> None:
        """Accept a practical one-second live-display interval."""
        settings = MonitorSettings(sample_interval_s=1.0)
        self.assertEqual(settings.sample_interval_s, 1.0)

    def test_duration_minutes_convert_to_seconds(self) -> None:
        """Convert the GUI duration in minutes for worker timing."""
        settings = SessionSettings(
            output_directory=Path("C:/Temp"),
            test_name="Test",
            sample_interval_s=1.0,
            duration_minutes=2.5,
            meter_rate=MeterRate.SLOW,
        )
        self.assertEqual(settings.duration_s, 150.0)


if __name__ == "__main__":
    unittest.main()

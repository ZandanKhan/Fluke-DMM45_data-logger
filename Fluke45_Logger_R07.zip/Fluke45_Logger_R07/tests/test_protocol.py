"""Unit tests for Fluke 45 protocol parsing."""

from __future__ import annotations

import unittest

from fluke45.errors import IdentityError, ProtocolError
from fluke45.protocol import parse_identity, parse_measurement_response


class IdentityParserTests(unittest.TestCase):
    """Verify identification parsing and model validation."""

    def test_valid_identity(self) -> None:
        """Parse a documented Fluke 45 identity response."""
        identity = parse_identity("FLUKE, 45, 1234567, 1.0 D1.0")
        self.assertEqual(identity.manufacturer, "FLUKE")
        self.assertEqual(identity.model, "45")
        self.assertEqual(identity.serial_number, "1234567")

    def test_rejects_other_model(self) -> None:
        """Reject an instrument that is not a Fluke 45."""
        with self.assertRaises(IdentityError):
            parse_identity("FLUKE, 8846A, 1234567, 1.0")

    def test_rejects_empty_serial_number(self) -> None:
        """Reject an identification response without a serial number."""
        with self.assertRaises(IdentityError):
            parse_identity("FLUKE, 45, , 1.0 D1.0")


class MeasurementParserTests(unittest.TestCase):
    """Verify primary and dual-display response parsing."""

    def test_primary_only_format_two(self) -> None:
        """Parse a primary display value with units."""
        primary, secondary = parse_measurement_response(
            "+1.2345E+0 VDC"
        )
        self.assertAlmostEqual(primary.value, 1.2345)
        self.assertEqual(primary.unit, "VDC")
        self.assertIsNone(secondary)

    def test_dual_display_format_two(self) -> None:
        """Parse two comma-separated values with units."""
        primary, secondary = parse_measurement_response(
            "+1.2345E+0 VDC, +6.7890E+3 HZ"
        )
        self.assertAlmostEqual(primary.value, 1.2345)
        self.assertIsNotNone(secondary)
        assert secondary is not None
        self.assertAlmostEqual(secondary.value, 6789.0)
        self.assertEqual(secondary.unit, "HZ")

    def test_positive_overload_value(self) -> None:
        """Parse the documented positive-overload numeric sentinel."""
        primary, secondary = parse_measurement_response("+1E+9 VDC")
        self.assertEqual(primary.value, 1_000_000_000.0)
        self.assertEqual(primary.unit, "VDC")
        self.assertIsNone(secondary)

    def test_negative_overload_value(self) -> None:
        """Parse the documented negative-overload numeric sentinel."""
        primary, secondary = parse_measurement_response("-1E+9 VDC")
        self.assertEqual(primary.value, -1_000_000_000.0)
        self.assertIsNone(secondary)

    def test_rejects_unexpected_text(self) -> None:
        """Reject a prompt or arbitrary text as a measurement."""
        with self.assertRaises(ProtocolError):
            parse_measurement_response("=>")

    def test_rejects_more_than_two_values(self) -> None:
        """Reject a malformed response containing a third value."""
        with self.assertRaises(ProtocolError):
            parse_measurement_response("1 VDC, 2 HZ, 3 ADC")


if __name__ == "__main__":
    unittest.main()

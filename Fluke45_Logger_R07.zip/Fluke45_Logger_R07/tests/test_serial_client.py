"""Integration-style tests for prompt-synchronized serial transactions."""

from __future__ import annotations

import sys
import types
import unittest
from collections import deque
from unittest.mock import patch

try:
    import serial
except ModuleNotFoundError:
    serial = types.ModuleType("serial")

    class _SerialException(OSError):
        """Fallback serial exception used only by local self-tests."""

    class _SerialTimeoutException(_SerialException):
        """Fallback serial timeout used only by local self-tests."""

    serial.SerialException = _SerialException
    serial.SerialTimeoutException = _SerialTimeoutException
    serial.STOPBITS_ONE = 1
    serial.SEVENBITS = 7
    serial.EIGHTBITS = 8
    serial.PARITY_EVEN = "E"
    serial.PARITY_ODD = "O"
    serial.PARITY_NONE = "N"
    serial.Serial = object
    sys.modules["serial"] = serial

from fluke45.errors import CommandError, ExecutionError, ProtocolError
from fluke45.models import ParityMode, SerialSettings
from fluke45.serial_client import Fluke45SerialClient


class FakeSerialStream:
    """Provide deterministic Fluke 45 response and prompt data.

    Args:
        echo_enabled: Whether commands are echoed before their responses.
    """

    def __init__(self, echo_enabled: bool = True) -> None:
        """Initialize an open fake serial stream.

        Args:
            echo_enabled: Whether commands are echoed before responses.
        """
        self.is_open = True
        self.echo_enabled = echo_enabled
        self._lines: deque[bytes] = deque()

    def reset_input_buffer(self) -> None:
        """Clear queued fake input lines."""
        self._lines.clear()

    def reset_output_buffer(self) -> None:
        """Accept the output-buffer reset operation."""

    def write(self, payload: bytes) -> int:
        """Queue a documented response for one known command.

        Args:
            payload: Bytes written by the serial client.

        Returns:
            Number of accepted bytes.
        """
        if payload == b"\x03":
            self._lines.extend((b"\r\n", b"=>\r\n"))
        elif payload == b"*IDN?\r":
            self._queue_transaction(
                "*IDN?",
                ("FLUKE, 45, 1234567, 1.0 D1.0",),
                "=>",
            )
        elif payload == b"FORMAT 2\r":
            self._queue_transaction("FORMAT 2", (), "=>")
        elif payload == b"VAL?\r":
            self._queue_transaction(
                "VAL?",
                ("+1.2345E+0 VDC, +6.0000E+1 HZ",),
                "=>",
            )
        elif payload == b"BAD\r":
            self._queue_transaction("BAD", (), "?>")
        elif payload == b"BLOCKED\r":
            self._queue_transaction("BLOCKED", (), "!>")
        return len(payload)

    def flush(self) -> None:
        """Accept a serial flush operation."""

    def readline(self) -> bytes:
        """Return the next queued response line.

        Returns:
            One response line or empty bytes when no data remains.
        """
        if self._lines:
            return self._lines.popleft()
        return b""

    def close(self) -> None:
        """Mark the fake serial port as closed."""
        self.is_open = False

    def _queue_transaction(
        self,
        command: str,
        response_lines: tuple[str, ...],
        prompt: str,
    ) -> None:
        """Queue one complete command transaction.

        Args:
            command: Command text without a terminator.
            response_lines: Data lines returned by the meter.
            prompt: Final meter prompt.
        """
        if self.echo_enabled:
            self._lines.append(f"{command}\r\n".encode("ascii"))
        for line in response_lines:
            self._lines.append(f"{line}\r\n".encode("ascii"))
        self._lines.append(f"{prompt}\r\n".encode("ascii"))


class SerialClientTests(unittest.TestCase):
    """Verify complete command, response, echo, and prompt handling."""

    def test_open_identify_and_read_dual_display(self) -> None:
        """Identify the meter and parse a dual-display transaction."""
        fake_stream = FakeSerialStream()
        client = self._open_client(fake_stream)
        identity = client.open()
        raw_response, primary, secondary = client.read_display()
        client.close()

        self.assertEqual(identity.model, "45")
        self.assertTrue(raw_response.startswith("+1.2345"))
        self.assertEqual(primary.unit, "VDC")
        self.assertIsNotNone(secondary)
        assert secondary is not None
        self.assertEqual(secondary.unit, "HZ")
        self.assertFalse(fake_stream.is_open)

    def test_echo_disabled_transaction(self) -> None:
        """Accept responses when the meter command echo is disabled."""
        fake_stream = FakeSerialStream(echo_enabled=False)
        client = self._open_client(fake_stream)
        client.open()
        _, primary, secondary = client.read_display()
        client.close()

        self.assertAlmostEqual(primary.value, 1.2345)
        self.assertIsNotNone(secondary)

    def test_command_error_prompt(self) -> None:
        """Convert the command-error prompt into a typed exception."""
        fake_stream = FakeSerialStream()
        client = self._open_client(fake_stream)
        client.open()
        with self.assertRaises(CommandError):
            client.command("BAD")
        client.close()

    def test_execution_error_prompt(self) -> None:
        """Convert the execution-error prompt into a typed exception."""
        fake_stream = FakeSerialStream()
        client = self._open_client(fake_stream)
        client.open()
        with self.assertRaises(ExecutionError):
            client.command("BLOCKED")
        client.close()

    def test_rejects_non_ascii_command(self) -> None:
        """Reject a command outside the meter's ASCII command set."""
        fake_stream = FakeSerialStream()
        client = self._open_client(fake_stream)
        client.open()
        with self.assertRaises(ProtocolError):
            client.command("VOLT Ω")
        client.close()

    def test_serial_framing_modes(self) -> None:
        """Map meter parity selections to the required data framing."""
        framing = Fluke45SerialClient._serial_framing
        self.assertEqual(
            framing(ParityMode.NONE),
            (serial.EIGHTBITS, serial.PARITY_NONE),
        )
        self.assertEqual(
            framing(ParityMode.EVEN),
            (serial.SEVENBITS, serial.PARITY_EVEN),
        )
        self.assertEqual(
            framing(ParityMode.ODD),
            (serial.SEVENBITS, serial.PARITY_ODD),
        )

    @staticmethod
    def _open_client(
        fake_stream: FakeSerialStream,
    ) -> Fluke45SerialClient:
        """Create a serial client patched to use a fake stream.

        Args:
            fake_stream: Fake serial object returned by ``serial.Serial``.

        Returns:
            Client configured for a simulated COM4 connection.
        """
        settings = SerialSettings(
            port="COM4",
            baud_rate=9600,
            parity=ParityMode.NONE,
        )
        patcher = patch(
            "fluke45.serial_client.serial.Serial",
            return_value=fake_stream,
        )
        patcher.start()
        client = Fluke45SerialClient(settings)
        original_close = client.close

        def close_with_unpatch() -> None:
            """Close the fake stream and remove the active patch."""
            original_close()
            patcher.stop()

        client.close = close_with_unpatch  # type: ignore[method-assign]
        return client


if __name__ == "__main__":
    unittest.main()

"""Static source-quality checks for the production package."""

from __future__ import annotations

import ast
import unittest
from pathlib import Path

PACKAGE_DIRECTORY = Path(__file__).resolve().parents[1] / "fluke45"
ENTRY_POINT = Path(__file__).resolve().parents[1] / "fluke45_logger.py"


class SourceQualityTests(unittest.TestCase):
    """Verify enterprise source conventions that can be checked locally."""

    @staticmethod
    def _source_files() -> list[Path]:
        """Return all production Python source files.

        Returns:
            Sorted production source paths.
        """
        return sorted(PACKAGE_DIRECTORY.glob("*.py")) + [ENTRY_POINT]

    def test_source_lines_do_not_exceed_79_characters(self) -> None:
        """Reject production source lines longer than 79 characters."""
        violations: list[str] = []
        for path in self._source_files():
            for line_number, line in enumerate(
                path.read_text(encoding="utf-8").splitlines(),
                start=1,
            ):
                if len(line) > 79:
                    violations.append(
                        f"{path.name}:{line_number}:{len(line)}"
                    )
        self.assertEqual(violations, [])

    def test_modules_classes_and_functions_have_docstrings(self) -> None:
        """Require module, class, and function docstrings."""
        missing: list[str] = []
        for path in self._source_files():
            tree = ast.parse(path.read_text(encoding="utf-8"))
            if ast.get_docstring(tree) is None:
                missing.append(f"{path.name}:module")
            for node in ast.walk(tree):
                if isinstance(
                    node,
                    (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef),
                ) and ast.get_docstring(node) is None:
                    missing.append(f"{path.name}:{node.name}")
        self.assertEqual(missing, [])

    def test_functions_have_argument_and_return_annotations(self) -> None:
        """Require type annotations on production functions."""
        missing: list[str] = []
        for path in self._source_files():
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if not isinstance(
                    node,
                    (ast.FunctionDef, ast.AsyncFunctionDef),
                ):
                    continue
                if node.returns is None:
                    missing.append(f"{path.name}:{node.name}:return")
                arguments = (
                    node.args.posonlyargs
                    + node.args.args
                    + node.args.kwonlyargs
                )
                for argument in arguments:
                    if argument.arg in {"self", "cls"}:
                        continue
                    if argument.annotation is None:
                        missing.append(
                            f"{path.name}:{node.name}:{argument.arg}"
                        )
                if (
                    node.args.vararg is not None
                    and node.args.vararg.annotation is None
                ):
                    missing.append(
                        f"{path.name}:{node.name}:*"
                        f"{node.args.vararg.arg}"
                    )
                if (
                    node.args.kwarg is not None
                    and node.args.kwarg.annotation is None
                ):
                    missing.append(
                        f"{path.name}:{node.name}:**"
                        f"{node.args.kwarg.arg}"
                    )
        self.assertEqual(missing, [])

    def test_no_generic_exception_handlers(self) -> None:
        """Reject broad ``except Exception`` handlers."""
        violations: list[str] = []
        for path in self._source_files():
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if not isinstance(node, ast.ExceptHandler):
                    continue
                if node.type is None:
                    violations.append(f"{path.name}:{node.lineno}:bare")
                elif (
                    isinstance(node.type, ast.Name)
                    and node.type.id in {"Exception", "BaseException"}
                ):
                    violations.append(
                        f"{path.name}:{node.lineno}:{node.type.id}"
                    )
        self.assertEqual(violations, [])

    def test_no_print_calls_in_production_code(self) -> None:
        """Require native logging instead of Python print calls."""
        violations: list[str] = []
        for path in self._source_files():
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call):
                    continue
                if isinstance(node.func, ast.Name):
                    if node.func.id == "print":
                        violations.append(
                            f"{path.name}:{node.lineno}"
                        )
        self.assertEqual(violations, [])


if __name__ == "__main__":
    unittest.main()

"""Tests for Tcl/Tk runtime discovery and configuration."""

from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fluke45.tk_runtime import (
    TkRuntimeError,
    configure_tk_runtime,
    discover_tk_runtime,
)


class TkRuntimeTests(unittest.TestCase):
    """Verify robust Tcl/Tk library discovery."""

    def assert_same_directory(
        self,
        actual: Path | str,
        expected: Path | str,
    ) -> None:
        """Assert that two path spellings identify the same directory.

        Windows can represent one directory using either a normal long path
        or an 8.3 short path. Exact string comparison is therefore invalid
        for filesystem identity tests.

        Args:
            actual: Path returned by the production code.
            expected: Path created by the test fixture.
        """
        actual_path = Path(actual)
        expected_path = Path(expected)
        self.assertTrue(
            actual_path.samefile(expected_path),
            msg=(
                "Directories do not identify the same location: "
                f"{actual_path!s} != {expected_path!s}"
            ),
        )

    def test_discovers_standard_windows_layout(self) -> None:
        """Find Tcl and Tk libraries beneath a Python root."""
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            tcl_library = root / "tcl" / "tcl8.6"
            tk_library = root / "tcl" / "tk8.6"
            tcl_library.mkdir(parents=True)
            tk_library.mkdir(parents=True)
            (tcl_library / "init.tcl").write_text(
                "# test",
                encoding="utf-8",
            )
            (tk_library / "tk.tcl").write_text(
                "# test",
                encoding="utf-8",
            )

            with patch.dict(os.environ, {}, clear=True):
                runtime = discover_tk_runtime([root])

            self.assert_same_directory(
                runtime.tcl_library,
                tcl_library,
            )
            self.assert_same_directory(
                runtime.tk_library,
                tk_library,
            )

    def test_uses_valid_environment_paths(self) -> None:
        """Prefer valid process-local Tcl and Tk variables."""
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            tcl_library = root / "custom_tcl"
            tk_library = root / "custom_tk"
            tcl_library.mkdir()
            tk_library.mkdir()
            (tcl_library / "init.tcl").write_text(
                "# test",
                encoding="utf-8",
            )
            (tk_library / "tk.tcl").write_text(
                "# test",
                encoding="utf-8",
            )
            environment = {
                "TCL_LIBRARY": str(tcl_library),
                "TK_LIBRARY": str(tk_library),
            }

            with patch.dict(os.environ, environment, clear=True):
                runtime = discover_tk_runtime([root / "missing"])

            self.assert_same_directory(
                runtime.tcl_library,
                tcl_library,
            )
            self.assert_same_directory(
                runtime.tk_library,
                tk_library,
            )

    def test_configure_sets_process_environment(self) -> None:
        """Write discovered library locations to the process environment."""
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            tcl_library = root / "tcl" / "tcl8.6"
            tk_library = root / "tcl" / "tk8.6"
            tcl_library.mkdir(parents=True)
            tk_library.mkdir(parents=True)
            (tcl_library / "init.tcl").touch()
            (tk_library / "tk.tcl").touch()

            with patch.dict(os.environ, {}, clear=True):
                configure_tk_runtime([root])
                self.assert_same_directory(
                    os.environ["TCL_LIBRARY"],
                    tcl_library,
                )
                self.assert_same_directory(
                    os.environ["TK_LIBRARY"],
                    tk_library,
                )

    def test_missing_libraries_raise_specific_error(self) -> None:
        """Report incomplete Python Tcl/Tk installations explicitly."""
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            with patch.dict(os.environ, {}, clear=True):
                with self.assertRaises(TkRuntimeError):
                    discover_tk_runtime([root])


if __name__ == "__main__":
    unittest.main()

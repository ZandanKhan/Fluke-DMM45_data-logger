"""Static user-interface contract tests for standard Tkinter."""

from __future__ import annotations

import ast
import unittest
from pathlib import Path


class UserInterfaceContractTests(unittest.TestCase):
    """Verify that the GUI uses only Python standard Tkinter widgets."""

    @staticmethod
    def _app_source() -> tuple[str, ast.Module]:
        """Load and parse the GUI source.

        Returns:
            Source text and parsed abstract syntax tree.
        """
        source_path = (
            Path(__file__).resolve().parents[1]
            / "fluke45"
            / "app.py"
        )
        source = source_path.read_text(encoding="utf-8")
        return source, ast.parse(source)

    def test_ttkbootstrap_is_not_used(self) -> None:
        """Reject all ttkbootstrap imports and references."""
        source, _ = self._app_source()
        self.assertNotIn("ttkbootstrap", source.lower())
        self.assertNotIn("bootstyle", source.lower())

    def test_standard_tkinter_is_used(self) -> None:
        """Require standard Tkinter and ttk imports."""
        source, _ = self._app_source()
        self.assertIn("import tkinter as tk", source)
        self.assertIn("from tkinter import", source)
        self.assertIn("ttk", source)

    def test_standard_scrolled_text_is_used(self) -> None:
        """Require the standard-library ScrolledText widget."""
        source, _ = self._app_source()
        self.assertIn("scrolledtext.ScrolledText(", source)

    def test_root_class_is_tkinter_tk(self) -> None:
        """Require the application root to inherit from ``tk.Tk``."""
        _, tree = self._app_source()
        class_nodes = [
            node
            for node in tree.body
            if isinstance(node, ast.ClassDef)
            and node.name == "Fluke45LoggerApp"
        ]
        self.assertEqual(len(class_nodes), 1)
        base_names = [ast.unparse(base) for base in class_nodes[0].bases]
        self.assertIn("tk.Tk", base_names)

    def test_live_display_controls_are_present(self) -> None:
        """Require continuous live-display start and stop controls."""
        source, _ = self._app_source()
        self.assertIn("START LIVE DISPLAY", source)
        self.assertIn("STOP LIVE DISPLAY", source)
        self.assertIn("Live interval (s)", source)

    def test_csv_duration_is_in_minutes(self) -> None:
        """Require the CSV duration control to use minutes."""
        source, _ = self._app_source()
        self.assertIn("Duration (min, 0 = continuous)", source)



if __name__ == "__main__":
    unittest.main()

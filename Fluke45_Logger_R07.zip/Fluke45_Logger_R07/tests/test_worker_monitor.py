"""Unit tests for the worker live-display acquisition mode."""

from __future__ import annotations

import queue
import threading
import time
import unittest

from fluke45.models import (
    EventKind,
    MeasurementValue,
    MonitorSettings,
    WorkerEvent,
)
from fluke45.worker import InstrumentWorker


class _FakeClient:
    """Provide deterministic responses for worker monitor tests."""

    def __init__(self) -> None:
        """Initialize command history."""
        self.commands: list[str] = []

    def command(self, command_text: str) -> list[str]:
        """Record a command and return no response lines.

        Args:
            command_text: ASCII command sent by the worker.

        Returns:
            Empty response-line list.
        """
        self.commands.append(command_text)
        return []

    def read_display(
        self,
    ) -> tuple[str, MeasurementValue, MeasurementValue | None]:
        """Return a deterministic dual-display reading.

        Returns:
            Raw response, primary value, and secondary value.
        """
        return (
            "+1.0000E+0 VDC, +6.0000E+1 HZ",
            MeasurementValue(1.0, "VDC", "+1.0000E+0 VDC"),
            MeasurementValue(60.0, "HZ", "+6.0000E+1 HZ"),
        )


class WorkerMonitorTests(unittest.TestCase):
    """Verify monitor lifecycle events and live readings."""

    @staticmethod
    def _build_worker() -> InstrumentWorker:
        """Build a worker instance without opening a serial port.

        Returns:
            Worker configured with a deterministic fake client.
        """
        worker = object.__new__(InstrumentWorker)
        worker._event_queue = queue.Queue()  # type: ignore[attr-defined]
        worker._shutdown_event = threading.Event()  # type: ignore[attr-defined]
        worker._client = _FakeClient()  # type: ignore[attr-defined]
        worker._session_writer = None  # type: ignore[attr-defined]
        worker._session_settings = None  # type: ignore[attr-defined]
        worker._monitor_settings = None  # type: ignore[attr-defined]
        worker._next_monitor_sample_monotonic = 0.0  # type: ignore[attr-defined]
        worker._consecutive_errors = 0  # type: ignore[attr-defined]
        return worker

    def test_monitor_start_and_live_reading(self) -> None:
        """Start monitoring and emit a live reading without CSV data."""
        worker = self._build_worker()
        settings = MonitorSettings(sample_interval_s=1.0)
        worker._start_monitor(settings)  # type: ignore[attr-defined]
        start_event = worker._event_queue.get_nowait()  # type: ignore[attr-defined]
        self.assertIsInstance(start_event, WorkerEvent)
        self.assertEqual(start_event.kind, EventKind.MONITOR_STARTED)

        worker._next_monitor_sample_monotonic = (  # type: ignore[attr-defined]
            time.monotonic() - 1.0
        )
        worker._run_scheduled_monitor_sample()  # type: ignore[attr-defined]
        reading_event = worker._event_queue.get_nowait()  # type: ignore[attr-defined]
        self.assertEqual(reading_event.kind, EventKind.LIVE_READING)
        self.assertEqual(reading_event.payload.sample_index, 0)

    def test_monitor_stop_event(self) -> None:
        """Stop an active monitor and emit a lifecycle event."""
        worker = self._build_worker()
        worker._monitor_settings = MonitorSettings(  # type: ignore[attr-defined]
            sample_interval_s=1.0
        )
        worker._stop_monitor("Stopped")  # type: ignore[attr-defined]
        stop_event = worker._event_queue.get_nowait()  # type: ignore[attr-defined]
        self.assertEqual(stop_event.kind, EventKind.MONITOR_STOPPED)


if __name__ == "__main__":
    unittest.main()
